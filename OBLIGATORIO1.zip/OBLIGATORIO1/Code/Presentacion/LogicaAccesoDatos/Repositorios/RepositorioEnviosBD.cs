﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using LogicaAccesoDatos.EF;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.EntityFrameworkCore;

namespace LogicaAccesoDatos.Repositorios
{
    public class RepositorioEnviosBD : IRepositorioEnvio
    {
        public EmpresaContext Contexto { get; set; }

        public RepositorioEnviosBD(EmpresaContext contexto)
        {
            Contexto = contexto;
        }

        public void Add(Envio obj)
        {
            if (obj == null)
                throw new DatosInvalidosException("No se proporcionan datos para el alta del envío");

            Contexto.Envios.Add(obj);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(obj).State = EntityState.Added;
            Contexto.Entry(obj.Cliente).State = EntityState.Unchanged;
            Contexto.Entry(obj.Funcionario).State = EntityState.Unchanged;

            if (obj is Comun comun && comun.Agencia != null)
            {
                Contexto.Entry(comun.Agencia).State = EntityState.Unchanged;
            }


            Contexto.SaveChanges();
        }

        public List<Envio> FindAll()
        {
            var envios = Contexto.Envios
                        .Include(env => env.Cliente)
                            .ThenInclude(cliente => cliente.Nombre) 
                        .Include(env => env.Cliente)
                            .ThenInclude(cliente => cliente.Apellido) 
                        .Include(env => env.Funcionario)
                            .ThenInclude(funcionario => funcionario.Nombre)
                        .Include(env => env.Funcionario)
                            .ThenInclude(funcionario => funcionario.Apellido)
                        .Include(env => env.EtapasSeguimiento)
                        .ToList();

            var enviosComunes = Contexto.Envios
                .OfType<Comun>()
                .Include(env => env.Agencia)
                .ToList();

 
            return envios.Union(enviosComunes).ToList();
        }




        public Envio FindById(int id)
        {
            return Contexto.Envios
                    .Include(env => env.Cliente)
                    .Include(env => env.Funcionario)
                    .Where(env => env.Id == id)
                    .SingleOrDefault();
        }

        public void Remove(int id)
        {
            Envio aBorrar = FindById(id);

            if (aBorrar == null) throw new DatosInvalidosException("No existe el envío a borrar");

            Contexto.Envios.Remove(aBorrar);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(aBorrar).State = EntityState.Deleted;
            Contexto.SaveChanges();
        }

        public void Update(Envio obj)
        {
            if (obj == null)
                throw new DatosInvalidosException("No se proporcionan datos para el alta de tema");

            Envio aModificar = FindById(obj.Id);

            Contexto.Entry(aModificar).State = EntityState.Detached;

            Contexto.Envios.Update(obj);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(obj).State = EntityState.Modified;

            Contexto.SaveChanges();
        }
    }
}

