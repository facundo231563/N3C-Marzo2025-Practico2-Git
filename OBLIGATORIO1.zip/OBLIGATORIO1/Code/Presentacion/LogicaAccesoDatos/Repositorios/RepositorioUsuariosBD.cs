﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using LogicaAccesoDatos.EF;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.EntityFrameworkCore;
using static LogicaAccesoDatos.Repositorios.RepositorioUsuariosBD;

namespace LogicaAccesoDatos.Repositorios
{
    public class RepositorioUsuariosBD : IRepositorioUsuario
    {
        public EmpresaContext Contexto { get; set; }

        public RepositorioUsuariosBD(EmpresaContext contexto)
        {
            Contexto = contexto;
        }

        public void Add(Usuario obj)
        {
            if (obj == null)
                throw new DatosInvalidosException("No se proporcionan datos para el alta del usuario");

            // Buscar el rol en la BD antes de asignarlo
            var rolExistente = Contexto.Roles.Find(obj.Rol.Id);
            obj.Rol = rolExistente;

            Contexto.Usuarios.Add(obj);
            Contexto.Entry(obj.Rol).State = EntityState.Unchanged;
            Contexto.SaveChanges();
        }

        public List<Usuario> FindAll()
        {
            return Contexto.Usuarios.Include(usu => usu.Rol).ToList();
        }

        public Usuario FindById(int id)
        {
            return Contexto.Usuarios
                   .Include(usu => usu.Rol)
                   .Where(usu => usu.Id == id)
                   .SingleOrDefault();
        }

        public void Remove(int id)
        {
            Usuario aBorrar = FindById(id);

            if (aBorrar == null) throw new DatosInvalidosException("No existe el usuario a borrar");

            Contexto.Usuarios.Remove(aBorrar);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(aBorrar).State = EntityState.Deleted;
            Contexto.SaveChanges();
        }
        public void Update(Usuario obj)
        {
            if (obj == null)
                throw new DatosInvalidosException("No se proporcionan datos para la actualización del usuario");

            Usuario aModificar = FindById(obj.Id);
            if (aModificar == null)
                throw new DatosInvalidosException("El usuario no existe");

            // Recuperar el rol desde la base de datos en lugar de usar un objeto nuevo
            var rolExistente = Contexto.Roles.Find(obj.Rol.Id);

            Contexto.Entry(aModificar).State = EntityState.Detached; // Desvincular la entidad anterior

            obj.Rol = rolExistente; // Asignar el rol existente

            Contexto.Usuarios.Update(obj);
            Contexto.SaveChanges();
        }
    }
}
