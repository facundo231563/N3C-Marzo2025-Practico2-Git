﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LogicaAccesoDatos.EF
{
    // ESTA ES NUESTRA CLASE DE CONTEXTO DE EF
    public class EmpresaContext : DbContext
    {

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Envio> Envios { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<Urgente> Urgentes { get; set; }
        public DbSet<Comun> Comunes { get; set; }
        public DbSet<Agencia> Agencias { get; set; }
        public DbSet<EtapaSeguimiento> EtapasSeguimiento { get; set; }
        public DbSet<Auditoria> Auditorias { get; set; }



        //OPCIÓN DE CONFIGURACIÓN DE LA BD MEDIANTE INYECCIÓN DE DEPENDENCIA:
        public EmpresaContext(DbContextOptions opciones) : base(opciones)
        {
        }



        //Esta configuración se hizo con IA buscando evitar conflictos con claves foráneas y las cascadas
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Envio>().HasOne(u => u.Cliente).WithMany().OnDelete(DeleteBehavior.NoAction);
            modelBuilder.Entity<Envio>().HasOne(u => u.Funcionario).WithMany().OnDelete(DeleteBehavior.NoAction);

            //Cambio nombre columna discriminator a TipoEnvio en la bdd
            modelBuilder.Entity<Envio>().HasDiscriminator<string>("TipoEnvio");

            //TRUNCAMIENTO DE DATOS

            modelBuilder.Entity<Agencia>()
                        .Property(a => a.Latitud)
                        .HasColumnType("decimal(18, 6)");

            modelBuilder.Entity<Agencia>()
                    .Property(a => a.Longitud)
                    .HasColumnType("decimal(18, 6)");

            modelBuilder.Entity<Envio>()
                    .Property(e => e.Peso)
                    .HasConversion(
                        v => v.Valor,  // Convierte PesoEnvio a decimal al guardar en la base de datos
                        v => new PesoEnvio(v) // Convierte de decimal a PesoEnvio al leer de la base de datos
                    )
                    .HasColumnType("decimal(18, 2)");
        }

    }

}


