﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LogicaAccesoDatos.Migrations
{
    /// <inheritdoc />
    public partial class modificaciones : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EtapaSeguimiento_Envios_EnvioId",
                table: "EtapaSeguimiento");

            migrationBuilder.DropForeignKey(
                name: "FK_EtapaSeguimiento_Usuarios_FuncionarioId",
                table: "EtapaSeguimiento");

            migrationBuilder.DropPrimaryKey(
                name: "PK_EtapaSeguimiento",
                table: "EtapaSeguimiento");

            migrationBuilder.DropColumn(
                name: "IdRol",
                table: "Usuarios");

            migrationBuilder.RenameTable(
                name: "EtapaSeguimiento",
                newName: "Etapas");

            migrationBuilder.RenameIndex(
                name: "IX_EtapaSeguimiento_FuncionarioId",
                table: "Etapas",
                newName: "IX_Etapas_FuncionarioId");

            migrationBuilder.RenameIndex(
                name: "IX_EtapaSeguimiento_EnvioId",
                table: "Etapas",
                newName: "IX_Etapas_EnvioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Etapas",
                table: "Etapas",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Etapas_Envios_EnvioId",
                table: "Etapas",
                column: "EnvioId",
                principalTable: "Envios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Etapas_Usuarios_FuncionarioId",
                table: "Etapas",
                column: "FuncionarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Etapas_Envios_EnvioId",
                table: "Etapas");

            migrationBuilder.DropForeignKey(
                name: "FK_Etapas_Usuarios_FuncionarioId",
                table: "Etapas");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Etapas",
                table: "Etapas");

            migrationBuilder.RenameTable(
                name: "Etapas",
                newName: "EtapaSeguimiento");

            migrationBuilder.RenameIndex(
                name: "IX_Etapas_FuncionarioId",
                table: "EtapaSeguimiento",
                newName: "IX_EtapaSeguimiento_FuncionarioId");

            migrationBuilder.RenameIndex(
                name: "IX_Etapas_EnvioId",
                table: "EtapaSeguimiento",
                newName: "IX_EtapaSeguimiento_EnvioId");

            migrationBuilder.AddColumn<int>(
                name: "IdRol",
                table: "Usuarios",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_EtapaSeguimiento",
                table: "EtapaSeguimiento",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_EtapaSeguimiento_Envios_EnvioId",
                table: "EtapaSeguimiento",
                column: "EnvioId",
                principalTable: "Envios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_EtapaSeguimiento_Usuarios_FuncionarioId",
                table: "EtapaSeguimiento",
                column: "FuncionarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
