﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LogicaAccesoDatos.Migrations
{
    /// <inheritdoc />
    public partial class nuevoNombreTablaEtapas : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Etapas_Envios_EnvioId",
                table: "Etapas");

            migrationBuilder.DropForeignKey(
                name: "FK_Etapas_Usuarios_FuncionarioId",
                table: "Etapas");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Etapas",
                table: "Etapas");

            migrationBuilder.RenameTable(
                name: "Etapas",
                newName: "EtapasSeguimiento");

            migrationBuilder.RenameIndex(
                name: "IX_Etapas_FuncionarioId",
                table: "EtapasSeguimiento",
                newName: "IX_EtapasSeguimiento_FuncionarioId");

            migrationBuilder.RenameIndex(
                name: "IX_Etapas_EnvioId",
                table: "EtapasSeguimiento",
                newName: "IX_EtapasSeguimiento_EnvioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_EtapasSeguimiento",
                table: "EtapasSeguimiento",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_EtapasSeguimiento_Envios_EnvioId",
                table: "EtapasSeguimiento",
                column: "EnvioId",
                principalTable: "Envios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_EtapasSeguimiento_Usuarios_FuncionarioId",
                table: "EtapasSeguimiento",
                column: "FuncionarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EtapasSeguimiento_Envios_EnvioId",
                table: "EtapasSeguimiento");

            migrationBuilder.DropForeignKey(
                name: "FK_EtapasSeguimiento_Usuarios_FuncionarioId",
                table: "EtapasSeguimiento");

            migrationBuilder.DropPrimaryKey(
                name: "PK_EtapasSeguimiento",
                table: "EtapasSeguimiento");

            migrationBuilder.RenameTable(
                name: "EtapasSeguimiento",
                newName: "Etapas");

            migrationBuilder.RenameIndex(
                name: "IX_EtapasSeguimiento_FuncionarioId",
                table: "Etapas",
                newName: "IX_Etapas_FuncionarioId");

            migrationBuilder.RenameIndex(
                name: "IX_EtapasSeguimiento_EnvioId",
                table: "Etapas",
                newName: "IX_Etapas_EnvioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Etapas",
                table: "Etapas",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Etapas_Envios_EnvioId",
                table: "Etapas",
                column: "EnvioId",
                principalTable: "Envios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Etapas_Usuarios_FuncionarioId",
                table: "Etapas",
                column: "FuncionarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
