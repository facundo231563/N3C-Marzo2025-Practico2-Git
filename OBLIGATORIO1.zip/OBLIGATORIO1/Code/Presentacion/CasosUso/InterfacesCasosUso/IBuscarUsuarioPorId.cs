﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;

namespace CasosUso.InterfacesCasosUso
{
    public interface IBuscarUsuarioPorId
    {
        UsuarioDTO EjecutarBusqueda(int id);
    }
}
