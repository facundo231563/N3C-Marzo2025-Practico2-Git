﻿using System.ComponentModel.DataAnnotations;
using static CasosUso.DTOs.EtapaSeguimientoDTO;


namespace CasosUso.DTOs
{
    public class EnvioDTO
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El número de tracking es obligatorio.")]
        [Range(1, int.MaxValue, ErrorMessage = "El número de tracking debe ser mayor que 0.")]
        public int NroTracking { get; set; }

        [Required(ErrorMessage = "El peso es obligatorio.")]
        public decimal Peso { get; set; }

        public string Estado { get; set; }

        
        public int ClienteId { get; set; }
        public string? ClienteNombreCompleto { get; set; }

        
        public int FuncionarioId { get; set; }
        public string? FuncionarioNombreCompleto { get; set; }

        
        public int? AgenciaId { get; set; }
        public string? AgenciaNombre { get; set; }

        
        public bool EntregaEficiente { get; set; } = false;
        
        public string? DireccionPostal { get; set; }

        public List<EtapaSeguimientoDTO> EtapasSeguimiento { get; set; } = new List<EtapaSeguimientoDTO>();



        public EnvioDTO()
        {
            DireccionPostal = null; 
            
        }
    }
}