﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasosUso.DTOs
{
    public class EtapaSeguimientoDTO
    {
        public int Id { get; set; }
        public int EnvioId { get; set; }
        public int NroTracking { get; set; }
        public int FuncionarioId { get; set; }
        public string Comentario { get; set; }
        public DateTime Fecha { get; set; }
    }

}
