﻿using CasosUso.DTOs;
using LogicaAccesoDatos.EF;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnvioController : ControllerBase
    {


        private readonly EmpresaContext Contexto;

        public EnvioController(EmpresaContext context)
        {
            Contexto = context;
        }

        [HttpGet("{nroTracking}")]
        public IActionResult ObtenerEnvioPorTracking(int nroTracking)
        {
            var envio = Contexto.Envios
                .Include(e => e.Cliente)
                .Include(e => e.Funcionario)
                .Include(e => e.EtapasSeguimiento)
                .FirstOrDefault(e => e.NroTracking == nroTracking);

            if (envio == null)
                return NotFound(new { mensaje = "Envío no encontrado." });

            return Ok(MappersEnvio.ToEnvioDTO(envio));
        }
    }
}
