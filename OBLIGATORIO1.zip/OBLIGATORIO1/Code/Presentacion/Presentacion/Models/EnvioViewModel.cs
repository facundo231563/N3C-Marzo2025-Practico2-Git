﻿using CasosUso.DTOs;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Presentacion.Models
{
    using Microsoft.AspNetCore.Mvc.ModelBinding;
    using Microsoft.AspNetCore.Mvc.Rendering;

    public class EnvioViewModel
    {
        public EnvioDTO DTO { get; set; } = new EnvioDTO();

        [BindNever]
        public List<SelectListItem>? Clientes { get; set; }

        [BindNever]
        public List<SelectListItem>? Funcionarios { get; set; }

        [BindNever]
        public List<SelectListItem>? Agencias { get; set; }

        public bool EsUrgente { get; set; } 
    }
}
