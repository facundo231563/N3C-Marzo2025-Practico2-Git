﻿using CasosUso.DTOs;
using LogicaNegocio.EntidadesDominio;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Presentacion.Models
{
    public class UsuarioViewModel
    {
        public UsuarioDTO DTO { get; set; } 
        public List<SelectListItem> Roles { get; set; }
    }
}
