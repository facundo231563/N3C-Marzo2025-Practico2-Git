﻿using CasosUso.DTOs;

namespace Presentacion.Models
{
    public class LoginViewModel
    {
        public UsuarioDTO Usuario { get; set; }
    }
}
