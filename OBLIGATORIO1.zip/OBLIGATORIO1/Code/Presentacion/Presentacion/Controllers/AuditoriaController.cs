﻿using LogicaAccesoDatos.EF;
using LogicaNegocio.EntidadesDominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Presentacion.Controllers
{
    public class AuditoriaController : Controller
    {
        private readonly EmpresaContext Contexto;

        public AuditoriaController(EmpresaContext context)
        {
            Contexto = context;
        }

        public void RegistrarAuditoria(string accion, int usuarioId)
        {
            var auditoria = new Auditoria
            {
                Accion = accion,
                Fecha = DateTime.Now,
                UsuarioId = HttpContext.Session.GetInt32("UserId") ?? 0,
                FuncionarioId = usuarioId
            };

            Contexto.Auditorias.Add(auditoria);
            Contexto.SaveChanges();
        }
    }
}
