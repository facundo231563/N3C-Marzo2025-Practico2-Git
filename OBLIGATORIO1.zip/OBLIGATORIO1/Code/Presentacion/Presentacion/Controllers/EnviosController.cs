﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAccesoDatos.EF;
using LogicaAplicacion.CasosUsoConcreto;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.ValueObjects;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Presentacion.Models;
using System.Diagnostics;
using System.Linq;

namespace Presentacion.Controllers
{
    public class EnviosController : Controller
    {
        public IAltaEnvio CUAltaEnvio { get; set; }
        public IBajaEnvio CUBajaEnvio { get; set; }
        public IBuscarEnvioPorId CUBuscarEnvioPorId { get; set; }
        public IListadoEnvios CUListadoEnvios { get; set; }
        public IModificarEnvio CUModificarEnvio { get; set; }
        public EmpresaContext Contexto { get; set; }
        public IBuscarUsuarioPorId CUBuscarUsuarioPorId{ get; set; }

        public EnviosController(IAltaEnvio cuAltaEnvio, IBajaEnvio cuBajaEnvio, IBuscarEnvioPorId cuBuscarEnvioPorId,
                                IListadoEnvios cuListadoEnvios, IModificarEnvio cuModificarEnvio, EmpresaContext contexto, IBuscarUsuarioPorId cuBuscarUsuarioPorId)
        {
            CUAltaEnvio = cuAltaEnvio;
            CUBajaEnvio = cuBajaEnvio;
            CUBuscarEnvioPorId = cuBuscarEnvioPorId;
            CUListadoEnvios = cuListadoEnvios;
            CUModificarEnvio = cuModificarEnvio;
            Contexto = contexto;
            CUBuscarUsuarioPorId = cuBuscarUsuarioPorId;
        }

        public ActionResult Index()
        {
            IEnumerable<EnvioDTO> dtos = CUListadoEnvios.ObtenerListado();

            return View(dtos);
        }

        // GET: EnviosController/UrgenteCreate
        public ActionResult UrgenteCreate()
        {
            var model = new EnvioViewModel
            {
                DTO = new EnvioDTO(),
                Clientes = Contexto.Usuarios
                    .Where(u => u.Rol.Id == 3)
                    .Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"{u.Email.Valor}" })
                    .ToList(),
                Funcionarios = Contexto.Usuarios
                    .Where(u => u.Rol.Id == 2)
                    .Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"{u.Nombre.Valor} {u.Apellido.Valor}" })
                    .ToList()
            };

            return View(model);
        }

        // GET: EnviosController/ComunCreate
        public ActionResult ComunCreate()
        {
            var model = new EnvioViewModel
            {
                DTO = new EnvioDTO(),
                Clientes = Contexto.Usuarios
                    .Where(u => u.Rol.Id == 3)
                    .Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"{u.Email.Valor}" })
                    .ToList(),
                Funcionarios = Contexto.Usuarios
                    .Where(u => u.Rol.Id == 2)
                    .Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"{u.Nombre.Valor} {u.Apellido.Valor}" })
                    .ToList(),
                Agencias = Contexto.Agencias
                    .Select(a => new SelectListItem { Value = a.Id.ToString(), Text = a.Nombre.Valor })
                    .ToList()
            };

            return View(model);
        }

        // POST: EnviosController/UrgenteCreate
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UrgenteCreate(EnvioViewModel model)
        {
            if (!ModelState.IsValid)
            {
                RecargarListas(model);
                return View(model);
            }

            bool existeTracking = Contexto.Envios.Any(e => e.NroTracking == model.DTO.NroTracking);
            if (existeTracking)
            {
                ModelState.AddModelError("DTO.NroTracking", "El número de tracking ya existe.");
                RecargarListas(model);
                return View(model);
            }
                        
            var etapaInicial = new EtapaSeguimientoDTO
            {
                Comentario = "Ingresado en agencia de origen",
                Fecha = DateTime.Now,
                FuncionarioId = model.DTO.FuncionarioId
            };

            model.DTO.EtapasSeguimiento.Add(etapaInicial); 

            CUAltaEnvio.EjecutarAlta(model.DTO); 

            return RedirectToAction(nameof(Index));
        }

        // POST: EnviosController/ComunCreate
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ComunCreate(EnvioViewModel model)
        {
            if (!ModelState.IsValid)
            {
                RecargarListas(model); 
                return View(model);
            }

            if (string.IsNullOrWhiteSpace(model.DTO.AgenciaNombre) && model.DTO.AgenciaId.HasValue)
            {
                var agencia = Contexto.Agencias.FirstOrDefault(a => a.Id == model.DTO.AgenciaId.Value);
                model.DTO.AgenciaNombre = agencia?.Nombre.Valor ?? "Nombre Desconocido";
            }

            bool existeTracking = Contexto.Envios.Any(e => e.NroTracking == model.DTO.NroTracking);
            if (existeTracking)
            {
                ModelState.AddModelError("DTO.NroTracking", "El número de tracking ya existe. Debe ser único.");
                RecargarListas(model); 
                return View(model);
            }

            var etapaInicial = new EtapaSeguimientoDTO
            {
                Comentario = "Ingresado en agencia de origen",
                Fecha = DateTime.Now,
                FuncionarioId = model.DTO.FuncionarioId
            };

            model.DTO.EtapasSeguimiento.Add(etapaInicial);

            CUAltaEnvio.EjecutarAlta(model.DTO);
            return RedirectToAction(nameof(Index));
        }

        private void RecargarListas(EnvioViewModel model)
        {
            model.Clientes = Contexto.Usuarios
                .Where(u => u.Rol.Id == 3)
                .Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"{u.Email.Valor}" })
                .ToList();

            model.Funcionarios = Contexto.Usuarios
                .Where(u => u.Rol.Id == 2)
                .Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"{u.Nombre.Valor} {u.Apellido.Valor}" })
                .ToList();

            model.Agencias = Contexto.Agencias
                .Select(a => new SelectListItem { Value = a.Id.ToString(), Text = a.Nombre.Valor })
                .ToList();
        }

        public JsonResult ValidarTracking(int nroTracking)
        {
            bool existe = Contexto.Envios.Any(e => e.NroTracking == nroTracking);
            return Json(!existe);
        }

        public ActionResult ListarEnviosEnProceso()
        {
            var enviosEnProceso = Contexto.Envios
                .Include(e => e.EtapasSeguimiento)
                .Include(e => e.Cliente)
                    .ThenInclude(c => c.Nombre)
                .Include(e => e.Cliente)
                    .ThenInclude(c => c.Apellido)
                .Include(e => e.Funcionario)
                    .ThenInclude(f => f.Nombre)
                .Include(e => e.Funcionario)
                    .ThenInclude(f => f.Apellido)
                .Where(e => e.Estado == "EN_PROCESO")
                .Select(e => MappersEnvio.ToEnvioDTO(e))
                .ToList();

            var enviosComunes = Contexto.Envios
                .OfType<Comun>()
                .Include(env => env.Agencia)
                .Where(e => e.Estado == "EN_PROCESO")
                .Select(e => MappersEnvio.ToEnvioDTO(e))
                .ToList();

            
            var lista = enviosEnProceso
                .Union(enviosComunes)
                .GroupBy(env => env.NroTracking) 
                .Select(g => g.Last()) 
                .ToList();          

            return View(lista);
        }

        //POST
        [HttpPost]
        public ActionResult FinalizarEnvio(int id)
        {
            var envio = Contexto.Envios
                .Include(e => e.Funcionario)
                .Include(e => e.EtapasSeguimiento) 
                .FirstOrDefault(e => e.Id == id);

            if (envio != null)
            {
                envio.Estado = "EN_PROCESO";

                var nuevaEtapa = new EtapaSeguimiento
                {
                    EnvioId = envio.Id,
                    FuncionarioId = envio.Funcionario?.Id ?? 0,
                    Comentario = new ComentarioEtapa { Valor = "Envío finalizado y entregado" },
                    Fecha = DateTime.Now 
                };

                envio.Estado = "FINALIZADO";

                envio.EtapasSeguimiento ??= new List<EtapaSeguimiento>();
                envio.EtapasSeguimiento.Add(nuevaEtapa); 

                Contexto.SaveChanges();
            }

            return RedirectToAction("Index"); 
        }

        [HttpPost]
        public ActionResult AgregarComentario(int envioId, string comentario, int usuarioId)
        {
            if (comentario.Length > 30)
            {
                ModelState.AddModelError("Comentario", "El comentario debe tener un máximo de 30 caracteres.");
                return RedirectToAction("ListarEnviosEnProceso");
            }

            var envio = Contexto.Envios.Include(e => e.EtapasSeguimiento).FirstOrDefault(e => e.Id == envioId);
            var usuarioDTO = CUBuscarUsuarioPorId.EjecutarBusqueda(usuarioId);
            var usuario = MappersUsuario.ToUsuario(usuarioDTO);


            if (envio == null || usuario == null) return NotFound();

            var usuarioEnContexto = Contexto.ChangeTracker.Entries<Usuario>().FirstOrDefault(e => e.Entity.Id == usuario.Id);
            if (usuarioEnContexto != null)
            {
                usuario = usuarioEnContexto.Entity; // 📌 Usamos la instancia ya rastreada
            }
            else
            {
                Contexto.Attach(usuario);
            }



            var nuevaEtapa = new EtapaSeguimiento
            {
                Envio = envio,
                Funcionario = usuario,
                Comentario = new ComentarioEtapa { Valor = comentario },
                Fecha = DateTime.Now
            };

            envio.EtapasSeguimiento.Add(nuevaEtapa);
            Contexto.SaveChanges();

            return RedirectToAction("ListarEnviosEnProceso");
        }

        public ActionResult HistorialEtapas(int envioId)
        {
            var envio = Contexto.Envios.Include(e => e.EtapasSeguimiento)
                                       .FirstOrDefault(e => e.Id == envioId);

            if (envio == null) return NotFound();

            return View(envio.EtapasSeguimiento.Select(e => new EtapaSeguimientoDTO
            {
                Id = e.Id,
                EnvioId = e.EnvioId,
                FuncionarioId = e.FuncionarioId,
                Comentario = e.Comentario.Valor,
                Fecha = e.Fecha
            }).ToList());
        }
    }
}