﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using ExcepcionesPropias;
using LogicaAccesoDatos.EF;
using LogicaAplicacion.CasosUsoConcreto;
using LogicaNegocio.EntidadesDominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Presentacion.Models;

namespace Presentacion.Controllers
{
    public class UsuariosController : Controller
    {

        public IAltaUsuario CUAltaUsuario { get; set; }
        public IBajaUsuario CUBajaUsuario { get; set; }
        public IBuscarUsuarioPorId CUBuscarUsuarioPorId { get; set; }
        public IListadoUsuarios CUListadoUsuarios { get; set; }
        public IModificarUsuario CUModificarUsuario { get; set; }

        //Para poder cargar el combo de roles
        public EmpresaContext Contexto { get; set; }

        public UsuariosController(IAltaUsuario cuAltaUsuario, IBajaUsuario cuBajaUsuario, IBuscarUsuarioPorId cuBuscarUsuarioPorId, IListadoUsuarios cuListadoUsuarios, IModificarUsuario cuModificarUsuario, EmpresaContext contexto)
        {
            CUAltaUsuario = cuAltaUsuario;
            CUBajaUsuario = cuBajaUsuario;
            CUBuscarUsuarioPorId = cuBuscarUsuarioPorId;
            CUListadoUsuarios = cuListadoUsuarios;
            CUModificarUsuario = cuModificarUsuario;

            Contexto = contexto;
        }

        // GET: UsuarioController
        public ActionResult Index()
        {
            IEnumerable<UsuarioDTO> dtos = CUListadoUsuarios.ObtenerListado();
            return View(dtos);
        }

        // GET: UsuarioController/Details/5
        public ActionResult Details(int id)
        {
            UsuarioDTO dto = CUBuscarUsuarioPorId.EjecutarBusqueda(id);
            return View(dto);
        }

        // GET: UsuarioController/Create
        public ActionResult Create()
        {
            var model = new UsuarioViewModel
            {
                DTO = new UsuarioDTO(),
                //CARGO COMBO DE ROLES
                Roles = Contexto.Roles.Select(rol => new SelectListItem
                {
                    Value = rol.Id.ToString(),
                    Text = rol.Tipo
                }).ToList()
            };

            return View(model);
        }

        // POST: UsuarioController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(UsuarioViewModel model)
        {
            if (model == null || model.DTO == null)
            {
                ModelState.AddModelError("", "No se han proporcionado datos válidos para la creación del usuario.");
                return View(model);
            }

            try
            {
                CUAltaUsuario.EjecutarAlta(model.DTO);
                RegistrarAuditoria("Alta", model.DTO.Id);
                return RedirectToAction(nameof(Index));
            }
            catch (DatosInvalidosException ex)
            {
                ViewBag.Error = ex.Message;
                ModelState.AddModelError("", $"Error de datos: {ex.Message}");
                return View(model);
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Ha ocurrido un error inesperado";
                ModelState.AddModelError("", "Ha ocurrido un error inesperado.");
                return View(model);
            }
        }

        // GET: UsuarioController/Edit/5
        public ActionResult Edit(int id)
        {
            UsuarioDTO dto = CUBuscarUsuarioPorId.EjecutarBusqueda(id);

            if (dto == null)
                return NotFound();

            // Convertir `UsuarioDTO` en `UsuarioViewModel` para que la vista lo reciba correctamente
            var model = new UsuarioViewModel
            {
                DTO = dto,
                Roles = Contexto.Roles.Select(rol => new SelectListItem
                {
                    Value = rol.Id.ToString(),
                    Text = rol.Tipo
                }).ToList()
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, UsuarioViewModel model)
        {
            if (model.DTO == null)
            {
                ModelState.AddModelError("", "No se han proporcionado datos válidos para la edición del usuario.");
                return View(ObtenerUsuarioViewModel(id));
            }

            try
            {
                CUModificarUsuario.EjecutarModificacion(model.DTO);
                RegistrarAuditoria("Edición", model.DTO.Id);
                return RedirectToAction(nameof(Index));
            }
            catch (DatosInvalidosException ex)
            {
                ModelState.AddModelError("", ex.Message);
                // Retornar el modelo con roles
                return View(ObtenerUsuarioViewModel(id));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Ocurrió un error y no se realizó la modificación: " + ex.Message);
                return View(ObtenerUsuarioViewModel(id));
            }
        }

        private UsuarioViewModel ObtenerUsuarioViewModel(int id)
        {
            var usuario = Contexto.Usuarios.Include(u => u.Rol).FirstOrDefault(u => u.Id == id);

            if (usuario == null) return null;

            return new UsuarioViewModel
            {
                DTO = new UsuarioDTO
                {
                    Id = usuario.Id,
                    Nombre = usuario.Nombre.Valor,
                    Apellido = usuario.Apellido.Valor,
                    Email = usuario.Email.Valor,
                    Contrasena = usuario.Contrasena.Valor,
                    IdRol = usuario.Rol.Id
                },
                Roles = Contexto.Roles.Select(rol => new SelectListItem
                {
                    Value = rol.Id.ToString(),
                    Text = rol.Tipo
                }).ToList()
            };
        }

        // GET: UsuarioController/Delete/5
        public ActionResult Delete(int id)
        {
            UsuarioDTO dto = CUBuscarUsuarioPorId.EjecutarBusqueda(id);
            return View(dto);
        }

        // POST: UsuarioController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, UsuarioDTO dto)
        {
            try
            {
                CUBajaUsuario.EjecutarBaja(dto.Id);
                RegistrarAuditoria("Baja", dto.Id);
                return RedirectToAction(nameof(Index));
            }
            catch (DatosInvalidosException ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Ocurrió un error y no se realizó la baja";
            }
            return View(dto);
        }

        [HttpGet]
        public IActionResult Login()
        {
            // Evita problemas con modelos vacíos
            return View(new LoginViewModel { Usuario = new UsuarioDTO() });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            var usuario = Contexto.Usuarios
                            .Include(u => u.Rol)
                            .FirstOrDefault(u =>
                                    u.Email.Valor == model.Usuario.Email &&
                                    u.Contrasena.Valor == model.Usuario.Contrasena);


            if (usuario == null)
            {
                ModelState.AddModelError("", "Credenciales incorrectas.");
                return View(model);
            }

            if (usuario.Rol.Id == 3)
            {
                ModelState.AddModelError("", "No tienes permisos para acceder.");
                return View(model);
            }

            // Guardar datos de usuario en sesión
            HttpContext.Session.SetInt32("UserId", usuario.Id);
            HttpContext.Session.SetString("UserName", usuario.Nombre.Valor);
            HttpContext.Session.SetInt32("Rol", usuario.Rol.Id);

            return RedirectToAction("Index", "Usuarios");
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Envios");
        }

        private void RegistrarAuditoria(string accion, int usuarioId)
        {
            var auditoria = new Auditoria
            {
                Accion = accion,
                Fecha = DateTime.Now,
                UsuarioId = HttpContext.Session.GetInt32("UserId") ?? 0,
                FuncionarioId = usuarioId
            };

            Contexto.Auditorias.Add(auditoria);
            Contexto.SaveChanges();
        }
    }
}
