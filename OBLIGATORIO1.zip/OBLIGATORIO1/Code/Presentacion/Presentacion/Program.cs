using CasosUso.InterfacesCasosUso;
using LogicaAccesoDatos.EF;
using LogicaAccesoDatos.Repositorios;
using LogicaAplicacion.CasosUsoConcreto;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.  
builder.Services.AddControllersWithViews();

builder.Services.AddScoped<IAltaEnvio, AltaEnvio>();
builder.Services.AddScoped<IListadoEnvios, ListadoEnvios>();
builder.Services.AddScoped<IBuscarEnvioPorId, BuscarEnvioPorId>();
builder.Services.AddScoped<IBajaEnvio, BajaEnvio>();
builder.Services.AddScoped<IModificarEnvio, ModificarEnvio>();

builder.Services.AddScoped<IAltaUsuario, AltaUsuario>();
builder.Services.AddScoped<IListadoUsuarios, ListadoUsuarios>();
builder.Services.AddScoped<IBuscarUsuarioPorId, BuscarUsuarioPorId>();
builder.Services.AddScoped<IBajaUsuario, BajaUsuario>();
builder.Services.AddScoped<IModificarUsuario, ModificarUsuario>();

builder.Services.AddScoped<IRepositorioEnvio, RepositorioEnviosBD>();
builder.Services.AddScoped<IRepositorioUsuario, RepositorioUsuariosBD>();

//CONFIGURACI�N DE D.I. DEL CONTEXTO DE EF  
string strCon = builder.Configuration.GetConnectionString("MiConexion");
builder.Services.AddDbContext<EmpresaContext>(options => options.UseSqlServer(strCon));

//PARA EL LOGIN 
builder.Services.AddSession();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// Configure the HTTP request pipeline.  
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseSession();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
   name: "default",
   pattern: "{controller=Envios}/{action=Index}/{id?}");

app.Run();
