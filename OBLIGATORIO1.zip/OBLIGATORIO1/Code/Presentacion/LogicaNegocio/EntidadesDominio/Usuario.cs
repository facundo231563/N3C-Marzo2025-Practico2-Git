﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using LogicaNegocio.InterfacesDominio;
using LogicaNegocio.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.EntidadesDominio
{
    public class Usuario
    {
        public int Id { get; set; }
        public NombreUsuario Nombre { get; set; }

        public ApellidoUsuario Apellido { get; set; }
        public EmailUsuario Email { get; set; }
        public ContrasenaUsuario Contrasena { get; set; }
        public Rol Rol { get; set; }
    }
}
