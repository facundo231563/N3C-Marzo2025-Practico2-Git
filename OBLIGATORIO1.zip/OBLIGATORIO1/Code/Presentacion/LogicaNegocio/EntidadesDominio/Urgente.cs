﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.EntidadesDominio
{
    public class Urgente : Envio
    {
        public string DireccionPostal { get; set; }
        public bool EntregaEficiente { get; set; }
    }
}
