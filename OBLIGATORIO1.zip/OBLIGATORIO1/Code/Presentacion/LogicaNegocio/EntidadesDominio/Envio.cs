﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using LogicaNegocio.InterfacesDominio;
using LogicaNegocio.ValueObjects;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LogicaNegocio.EntidadesDominio
{

    public abstract class Envio
    {
        public int Id { get; set; }
        public int NroTracking { get; set; }
        public PesoEnvio Peso { get; set; } = new PesoEnvio(0);

        public string Estado { get; set; }
        public Usuario Cliente { get; set; } = new Usuario();

        public Usuario Funcionario { get; set; }
        public List<EtapaSeguimiento> EtapasSeguimiento { get; set; } = new List<EtapaSeguimiento>();
    }

}
