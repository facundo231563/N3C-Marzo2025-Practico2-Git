﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaNegocio.ValueObjects;

namespace LogicaNegocio.EntidadesDominio
{

    public class EtapaSeguimiento
    {
        public int Id { get; set; }
        public int EnvioId { get; set; }
        public Envio Envio { get; set; }
        public int FuncionarioId { get; set; }
        public Usuario Funcionario { get; set; }
        public ComentarioEtapa Comentario { get; set; }
        public DateTime Fecha { get; set; }
    }

}
