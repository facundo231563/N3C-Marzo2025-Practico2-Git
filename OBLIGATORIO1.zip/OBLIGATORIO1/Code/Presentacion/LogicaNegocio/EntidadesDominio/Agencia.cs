﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaNegocio.ValueObjects;

namespace LogicaNegocio.EntidadesDominio
{
    public class Agencia
    {
        public int Id { get; set; }
        public NombreAgencia Nombre { get; set; }
        public DireccionPostalAgencia DireccionPostal { get; set; }
        public decimal Latitud { get; set; }
        public decimal Longitud { get; set; }

    }
}
