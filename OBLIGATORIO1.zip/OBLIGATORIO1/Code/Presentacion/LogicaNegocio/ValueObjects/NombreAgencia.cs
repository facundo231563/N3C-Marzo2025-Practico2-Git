﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record NombreAgencia
    {

        public string Valor { get; init; }
        public NombreAgencia(string valor)
        {
            Valor = valor;
            Validar();
        }
        public NombreAgencia()
        {

        }

        private void Validar()
        {
            if (Valor.Length > 30)
                throw new DatosInvalidosException("El largo máximo del nombre es 30 caracteres");
        }
    }
}
