﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record DireccionPostalAgencia
    {
        public string Valor { get; init; }
        public DireccionPostalAgencia(string valor)
        {
            Valor = valor;
            Validar();
        }

        public DireccionPostalAgencia()
        {

        }

        private void Validar()
        {
            if (Valor.Length > 40)
                throw new DatosInvalidosException("El largo máximo de la dirección es 40 caracteres");
        }
    }
}
