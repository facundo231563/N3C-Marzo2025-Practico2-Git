﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record ComentarioEtapa
    {
        public string Valor { get; init; }
        public ComentarioEtapa(string valor)
        {
            Valor = valor;
            Validar();
        }

        public ComentarioEtapa()
        {

        }

        private void Validar()
        {
            if (Valor.Length > 100)
                throw new DatosInvalidosException("El largo máximo del comentario es 100 caracteres");
        }
    }
}

