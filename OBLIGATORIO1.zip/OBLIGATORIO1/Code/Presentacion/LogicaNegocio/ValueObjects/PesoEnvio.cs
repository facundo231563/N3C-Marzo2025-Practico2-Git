﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record PesoEnvio
    {
        public decimal Valor { get; init; }
        public PesoEnvio(decimal valor)
        {
            Valor = valor;
            Validar();
        }

        public PesoEnvio()
        {

        }

        private void Validar()
        {
            if (Valor < 0)
                throw new DatosInvalidosException("El peso del envío no puede ser menor a 0");
        }
    }
}
