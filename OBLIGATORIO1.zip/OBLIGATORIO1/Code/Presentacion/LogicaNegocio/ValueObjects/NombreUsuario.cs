﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record NombreUsuario
    {
        public string Valor { get; init; }
        public NombreUsuario(string valor)
        {
            Valor = valor;
            Validar();
        }
        public NombreUsuario()
        {
            
        }

        private void Validar()
        {
            if (Valor == null) throw new DatosInvalidosException("El nombre del usuario es requerido");
            if (Valor.Length > 20) throw new DatosInvalidosException("El largo máximo del nombre es 20 caracteres");

        }
    }
}
