﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record ContrasenaUsuario
    {
        public string Valor { get; init; }

        public ContrasenaUsuario(string valor)
        {
            Valor = valor;
            Validar();
        }
        public ContrasenaUsuario()
        {

        }

        private void Validar()
        {
            if (Valor == null) throw new DatosInvalidosException("La contraseña del usuario es requerida");
            if (Valor.Length > 15) throw new DatosInvalidosException("El largo máximo de la contraseña es 15 caracteres");
        }
    }
}

