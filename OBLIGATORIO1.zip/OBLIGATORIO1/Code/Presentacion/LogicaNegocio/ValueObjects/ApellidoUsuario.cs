﻿using ExcepcionesPropias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record ApellidoUsuario
    {
        public string Valor { get; init; }

        public ApellidoUsuario(string valor)
        {
            Valor = valor;
            Validar();
        }

        public ApellidoUsuario()
        {

        }

        private void Validar()
        {
            if (Valor == null) throw new DatosInvalidosException("El apellido del usuario es requerido");
            if (Valor.Length > 25) throw new DatosInvalidosException("El largo máximo del apellido es 25 caracteres");
        }
    }
}

