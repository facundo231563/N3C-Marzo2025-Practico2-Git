﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public class TipoRol
    {
        public string Valor { get; init; }

        public TipoRol(string valor)
        {
            Valor = valor;
            Validar();
        }

        public TipoRol()
        {

        }

        private void Validar()
        {
            if (Valor == "Cliente")//((Valor != "Administrador") || (Valor != "Funcionario") || (Valor != "Cliente"))
                throw new DatosInvalidosException("El rol no existe");
        }
    }
}
