﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.EntityFrameworkCore;

namespace LogicaNegocio.ValueObjects
{
    [Owned]
    public record EmailUsuario
    {
        public string Valor { get; init; }
        public EmailUsuario(string valor)
        {
            Valor = valor;
            Validar();
        }
        public EmailUsuario()
        {

        }

        private void Validar()
        {
            if (Valor == null) throw new DatosInvalidosException("El email del usuario es requerido");
            if (Valor.Length > 30) throw new DatosInvalidosException("El largo máximo del email es 30 caracteres");
        }
    }
}
