﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.ValueObjects;

namespace LogicaAplicacion.Mapeadores
{
    public class MappersUsuario
    {
        public static Usuario ToUsuario(UsuarioDTO dto)
        {      

            Usuario obj = new Usuario()
            {
                Id = dto.Id,
                Nombre = new NombreUsuario(dto.Nombre),
                Apellido = new ApellidoUsuario(dto.Apellido),
                Email = new EmailUsuario(dto.Email),
                Contrasena = new ContrasenaUsuario(dto.Contrasena)
            };
            obj.Rol = new Rol { Id = dto.IdRol};

            return obj;
        }

        public static UsuarioDTO ToUsuarioDTO(Usuario usu)
        {
            UsuarioDTO dto = null;

            if (usu != null)
            {
                dto = new UsuarioDTO()
                {
                    Id = usu.Id,
                    Nombre = usu.Nombre.Valor,
                    Apellido = usu.Apellido.Valor,
                    Email = usu.Email.Valor,
                    Contrasena = usu.Contrasena.Valor,
                    IdRol = usu.Rol.Id,
                    TipoRol = usu.Rol.Tipo

                };
            }

            return dto;
        }

        public static IEnumerable<UsuarioDTO> ToListaUsuariosDTO(IEnumerable<Usuario> usuarios)
        {
            List<UsuarioDTO> lista = new List<UsuarioDTO>();

            foreach (Usuario usu in usuarios)
            {
                lista.Add(ToUsuarioDTO(usu));
            }

            return lista;
        }
    }
}

