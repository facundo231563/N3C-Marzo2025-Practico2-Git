﻿using System.Diagnostics;
using CasosUso.DTOs;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.ValueObjects;
using static CasosUso.DTOs.EtapaSeguimientoDTO;

public class MappersEnvio
{

    public static EnvioDTO ToEnvioDTO(Envio env)
    {
        EnvioDTO dto = new EnvioDTO
        {
            Id = env.Id,
            NroTracking = env.NroTracking,
            Peso = env.Peso?.Valor ?? 0, // Default value if null

            Estado = env.Estado,
            ClienteId = env.Cliente.Id,
            ClienteNombreCompleto = $"{env.Cliente.Nombre.Valor} {env.Cliente.Apellido.Valor}",
            FuncionarioId = env.Funcionario.Id,
            FuncionarioNombreCompleto = $"{env.Funcionario.Nombre.Valor} {env.Funcionario.Apellido.Valor}",

            EtapasSeguimiento = env.EtapasSeguimiento ?
                .Select(e => new EtapaSeguimientoDTO
                {
                    Id = e.Id,
                    EnvioId = e.EnvioId,
                    FuncionarioId = e.FuncionarioId,
                    Comentario = e.Comentario.Valor,
                    Fecha = e.Fecha
                })
                .ToList() ?? new List<EtapaSeguimientoDTO>()
        

        };

        if (env is Comun comun)
        {
            dto.AgenciaId = comun.Agencia?.Id;
            dto.AgenciaNombre = comun.Agencia?.Nombre.Valor ?? "Sin Nombre"; 
        }
        if (env is Urgente urgente)
        {
            dto.EntregaEficiente = urgente.EntregaEficiente;
            dto.DireccionPostal = urgente.DireccionPostal ?? "No aplica";
        }



        return dto;
    }

    public static Envio ToEnvio(EnvioDTO dto)
    {
        if (dto == null) return null;

        Envio obj;

        if (dto.AgenciaId.HasValue && dto.AgenciaId > 0)
        {
            obj = new Comun
            {
                Agencia = new Agencia
                {
                    Id = dto.AgenciaId.Value,
                    Nombre = !string.IsNullOrWhiteSpace(dto.AgenciaNombre)
                        ? new NombreAgencia { Valor = dto.AgenciaNombre }
                        : new NombreAgencia { Valor = "Sin Nombre" }
                }
            };
        }
        else
        {
            obj = new Urgente
            {
                DireccionPostal = dto.DireccionPostal,
                EntregaEficiente = dto.EntregaEficiente
            };
        }

        obj.Id = dto.Id;
        obj.NroTracking = dto.NroTracking;
        obj.Peso = new PesoEnvio(dto.Peso);
        obj.Estado = dto.Estado;
        obj.Cliente = new Usuario { Id = dto.ClienteId };
        obj.Funcionario = new Usuario { Id = dto.FuncionarioId };
        
        obj.EtapasSeguimiento = dto.EtapasSeguimiento?.Select(e => new EtapaSeguimiento
        {
            Envio = obj,  
            Comentario = new ComentarioEtapa { Valor = e.Comentario },
            Fecha = e.Fecha,
            FuncionarioId = e.FuncionarioId
        }).ToList() ?? new List<EtapaSeguimiento>();

        return obj;
    }
    public static IEnumerable<EnvioDTO> ToListaEnviosDTO(IEnumerable<Envio> envios)
    {
        return envios?.Select(env => ToEnvioDTO(env)).ToList() ?? new List<EnvioDTO>();
    }
}