﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class BuscarEnvioPorId : IBuscarEnvioPorId
    {
        public IRepositorioEnvio RepoEnvios { get; set; }

        public BuscarEnvioPorId(IRepositorioEnvio repo)
        {
            RepoEnvios = repo;
        }


        public EnvioDTO EjecutarBusqueda(int id)
        {
            Envio e = RepoEnvios.FindById(id);
            return MappersEnvio.ToEnvioDTO(e);
        }
    }
}
