﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.InterfacesCasosUso;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class BajaUsuario : IBajaUsuario
    {

        public IRepositorioUsuario RepoUsuarios { get; set; }

        public BajaUsuario(IRepositorioUsuario repo)
        {
            RepoUsuarios = repo;
        }

        public void EjecutarBaja(int id)
        {
            RepoUsuarios.Remove(id);
        }

    }
}
