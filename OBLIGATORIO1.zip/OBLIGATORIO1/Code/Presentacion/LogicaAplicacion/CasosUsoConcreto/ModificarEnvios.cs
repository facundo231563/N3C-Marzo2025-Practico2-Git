﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class ModificarEnvio : IModificarEnvio
    {
        public IRepositorioEnvio RepoEnvios { get; set; }

        public ModificarEnvio(IRepositorioEnvio repo)
        {
            RepoEnvios = repo;
        }

        public void EjecutarModificacion(EnvioDTO dto)
        {
            RepoEnvios.Update(MappersEnvio.ToEnvio(dto));
        }
    }
}
