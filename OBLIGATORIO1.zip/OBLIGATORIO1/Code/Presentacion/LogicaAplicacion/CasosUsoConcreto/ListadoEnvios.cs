﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class ListadoEnvios : IListadoEnvios
    {
        public IRepositorioEnvio RepoEnvios{ get; set; }

        public ListadoEnvios(IRepositorioEnvio repoEnvios)
        {
            RepoEnvios = repoEnvios;
        }

        public IEnumerable<EnvioDTO> ObtenerListado()
        {
            return MappersEnvio.ToListaEnviosDTO(RepoEnvios.FindAll());
        }
    }
}
