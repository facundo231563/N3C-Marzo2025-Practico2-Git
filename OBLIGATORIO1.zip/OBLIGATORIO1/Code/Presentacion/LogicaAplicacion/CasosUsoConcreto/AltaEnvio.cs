﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class AltaEnvio : IAltaEnvio
    {
        public IRepositorioEnvio RepoEnvios { get; set; }
        public AltaEnvio(IRepositorioEnvio repoEnvios)
        {
            RepoEnvios = repoEnvios;
        }
        public void EjecutarAlta(EnvioDTO dto)
        {
            RepoEnvios.Add(MappersEnvio.ToEnvio(dto));
        }
    }
}
