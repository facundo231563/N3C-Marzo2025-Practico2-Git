﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class BuscarUsuarioPorId : IBuscarUsuarioPorId
    {
        public IRepositorioUsuario RepoUsuarios { get; set; }

        public BuscarUsuarioPorId(IRepositorioUsuario repo)
        {
            RepoUsuarios = repo;
        }

        public UsuarioDTO EjecutarBusqueda(int id)
        {
            Usuario u = RepoUsuarios.FindById(id);
            return MappersUsuario.ToUsuarioDTO(u);
        }

    }
}
