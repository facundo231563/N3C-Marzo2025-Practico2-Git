﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class ModificarUsuario : IModificarUsuario
    {
        public IRepositorioUsuario RepoUsuarios { get; set; }

        public ModificarUsuario(IRepositorioUsuario repo)
        {
            RepoUsuarios = repo;
        }

        public void EjecutarModificacion(UsuarioDTO dto)
        {
            RepoUsuarios.Update(MappersUsuario.ToUsuario(dto));
        }
    }
}
