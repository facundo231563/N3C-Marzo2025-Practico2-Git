﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class ListadoUsuarios : IListadoUsuarios
    {
        public IRepositorioUsuario RepoUsuarios { get; set; }

        public ListadoUsuarios(IRepositorioUsuario repoUsuarios)
        {
            RepoUsuarios = repoUsuarios;
        }

        public IEnumerable<UsuarioDTO> ObtenerListado()
        {
            return MappersUsuario.ToListaUsuariosDTO(RepoUsuarios.FindAll());
        }
    }
}
