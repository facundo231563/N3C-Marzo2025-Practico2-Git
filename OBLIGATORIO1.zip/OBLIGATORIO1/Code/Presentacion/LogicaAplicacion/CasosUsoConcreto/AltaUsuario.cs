﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class AltaUsuario : IAltaUsuario
    {
        public IRepositorioUsuario RepoUsuarios { get; set; }
        public AltaUsuario(IRepositorioUsuario repoUsuarios)
        {
            RepoUsuarios = repoUsuarios;
        }
        public void EjecutarAlta(UsuarioDTO dto)
        {
            RepoUsuarios.Add(MappersUsuario.ToUsuario(dto));
        }
    }
}
