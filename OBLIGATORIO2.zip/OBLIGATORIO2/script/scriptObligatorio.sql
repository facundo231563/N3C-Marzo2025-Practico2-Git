USE [Obligatorio]
GO
/****** Object:  Table [dbo].[Agencias]    Script Date: 25/6/2025 10:08:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Agencias](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nombre_Valor] [nvarchar](max) NOT NULL,
	[DireccionPostal_Valor] [nvarchar](max) NOT NULL,
	[Latitud] [decimal](18, 6) NOT NULL,
	[Longitud] [decimal](18, 6) NOT NULL,
 CONSTRAINT [PK_Agencias] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Envios]    Script Date: 25/6/2025 10:08:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Envios](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[NroTracking] [int] NOT NULL,
	[Peso] [decimal](18, 2) NOT NULL,
	[Estado] [nvarchar](max) NOT NULL,
	[ClienteId] [int] NOT NULL,
	[FuncionarioId] [int] NOT NULL,
	[TipoEnvio] [nvarchar](8) NOT NULL,
	[AgenciaId] [int] NULL,
	[DireccionPostal] [nvarchar](max) NULL,
	[EntregaEficiente] [bit] NULL,
	[FechaEnviado] [datetime2](7) NOT NULL,
	[FechaEntregado] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_Envios] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EtapasSeguimiento]    Script Date: 25/6/2025 10:08:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EtapasSeguimiento](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EnvioId] [int] NOT NULL,
	[FuncionarioId] [int] NOT NULL,
	[Comentario_Valor] [nvarchar](max) NOT NULL,
	[Fecha] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_EtapasSeguimiento] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Roles]    Script Date: 25/6/2025 10:08:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Roles](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Tipo] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Roles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Usuarios]    Script Date: 25/6/2025 10:08:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Usuarios](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nombre_Valor] [nvarchar](max) NOT NULL,
	[Apellido_Valor] [nvarchar](max) NOT NULL,
	[Email_Valor] [nvarchar](max) NOT NULL,
	[Contrasena_Valor] [nvarchar](max) NOT NULL,
	[RolId] [int] NOT NULL,
 CONSTRAINT [PK_Usuarios] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Agencias] ON 
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (1, N'DAC', N'85000', CAST(100010.000000 AS Decimal(18, 6)), CAST(200010.000000 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (2, N'TURIL', N'11800', CAST(-34.905000 AS Decimal(18, 6)), CAST(-56.191000 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (3, N'TURISMAR', N'11800', CAST(-34.902500 AS Decimal(18, 6)), CAST(-56.186500 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (4, N'Agencia República', N'11800', CAST(-34.891000 AS Decimal(18, 6)), CAST(-56.165000 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (5, N'Copay Montevideo', N'11800', CAST(-34.900500 AS Decimal(18, 6)), CAST(-56.180500 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (6, N'Agencia Gral Flores', N'11800', CAST(-34.883500 AS Decimal(18, 6)), CAST(-56.165500 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (7, N'Jetmar', N'11000', CAST(-34.905800 AS Decimal(18, 6)), CAST(-56.191200 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (8, N'Destinico', N'11000', CAST(-34.906500 AS Decimal(18, 6)), CAST(-56.192000 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (9, N'Abtour', N'11000', CAST(-34.907000 AS Decimal(18, 6)), CAST(-56.193000 AS Decimal(18, 6)))
GO
INSERT [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES (10, N'Jorge Martinez', N'11000', CAST(-34.908000 AS Decimal(18, 6)), CAST(-56.194000 AS Decimal(18, 6)))
GO
SET IDENTITY_INSERT [dbo].[Agencias] OFF
GO
SET IDENTITY_INSERT [dbo].[Envios] ON 
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (123, 1, CAST(2.00 AS Decimal(18, 2)), N'FINALIZADO', 6, 5, N'Urgente', NULL, N'Calle Falsa 123', 0, CAST(N'2025-05-22T09:54:08.7288580' AS DateTime2), CAST(N'2025-05-22T09:54:41.8771961' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (124, 2, CAST(2.00 AS Decimal(18, 2)), N'FINALIZADO', 9, 8, N'Comun', 2, NULL, NULL, CAST(N'2025-05-22T09:55:26.1880696' AS DateTime2), CAST(N'2025-05-22T09:55:47.4376709' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (125, 3, CAST(2.00 AS Decimal(18, 2)), N'EN_PROCESO', 6, 3, N'Urgente', NULL, N'555 wall', 1, CAST(N'2025-05-22T09:56:14.5531430' AS DateTime2), CAST(N'0001-01-01T00:00:00.0000000' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (126, 4, CAST(1.00 AS Decimal(18, 2)), N'FINALIZADO', 6, 3, N'Comun', 9, NULL, NULL, CAST(N'2025-05-22T09:56:43.2321565' AS DateTime2), CAST(N'2025-05-22T09:59:06.9571177' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (127, 5, CAST(6.00 AS Decimal(18, 2)), N'EN_PROCESO', 9, 3, N'Urgente', NULL, N'Covif 2 vivienda 28', 0, CAST(N'2025-05-22T09:56:56.3921717' AS DateTime2), CAST(N'0001-01-01T00:00:00.0000000' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (128, 6, CAST(88.00 AS Decimal(18, 2)), N'FINALIZADO', 9, 3, N'Urgente', NULL, N'555 wall', 0, CAST(N'2025-05-22T09:57:09.6457186' AS DateTime2), CAST(N'2025-05-22T09:59:16.8092671' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (129, 7, CAST(9.00 AS Decimal(18, 2)), N'EN_PROCESO', 9, 3, N'Comun', 7, NULL, NULL, CAST(N'2025-05-22T09:57:28.8547817' AS DateTime2), CAST(N'0001-01-01T00:00:00.0000000' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (130, 8, CAST(15.00 AS Decimal(18, 2)), N'EN_PROCESO', 6, 11, N'Comun', 10, NULL, NULL, CAST(N'2025-05-22T09:57:45.3509247' AS DateTime2), CAST(N'0001-01-01T00:00:00.0000000' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (131, 9, CAST(25.00 AS Decimal(18, 2)), N'FINALIZADO', 6, 3, N'Urgente', NULL, N'18 de Julio 1634', 0, CAST(N'2025-05-22T09:58:32.5611950' AS DateTime2), CAST(N'2025-05-22T09:59:10.7025246' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (132, 10, CAST(10.00 AS Decimal(18, 2)), N'EN_PROCESO', 6, 8, N'Urgente', NULL, N'8 de Octubre 1095', 1, CAST(N'2025-05-22T09:58:58.7844052' AS DateTime2), CAST(N'0001-01-01T00:00:00.0000000' AS DateTime2))
GO
INSERT [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES (133, 1234, CAST(2.00 AS Decimal(18, 2)), N'FINALIZADO', 6, 5, N'Comun', 3, NULL, NULL, CAST(N'2025-05-26T20:59:34.8639308' AS DateTime2), CAST(N'2025-05-26T21:00:23.2578901' AS DateTime2))
GO
SET IDENTITY_INSERT [dbo].[Envios] OFF
GO
SET IDENTITY_INSERT [dbo].[EtapasSeguimiento] ON 
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (62, 123, 5, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:54:08.7288580' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (63, 123, 5, N'En camino por flores', CAST(N'2025-05-22T09:54:39.4178974' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (64, 123, 5, N'Envío finalizado y entregado', CAST(N'2025-05-22T09:54:41.8771961' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (65, 124, 8, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:55:26.1880696' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (66, 124, 8, N'Casi llegando', CAST(N'2025-05-22T09:55:44.1630475' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (67, 124, 8, N'Envío finalizado y entregado', CAST(N'2025-05-22T09:55:47.4376709' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (68, 125, 3, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:56:14.5531430' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (69, 126, 3, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:56:43.2321565' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (70, 127, 3, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:56:56.3921717' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (71, 128, 3, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:57:09.6457186' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (72, 129, 3, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:57:28.8547817' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (73, 130, 11, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:57:45.3509247' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (74, 131, 3, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:58:32.5611950' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (75, 132, 8, N'Ingresado en agencia de origen', CAST(N'2025-05-22T09:58:58.7844052' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (76, 126, 3, N'Envío finalizado y entregado', CAST(N'2025-05-22T09:59:06.9571177' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (77, 131, 3, N'Envío finalizado y entregado', CAST(N'2025-05-22T09:59:10.7025246' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (78, 128, 3, N'Envío finalizado y entregado', CAST(N'2025-05-22T09:59:16.8092671' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (79, 133, 5, N'Ingresado en agencia de origen', CAST(N'2025-05-26T20:59:34.8639308' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (80, 133, 5, N'En camino', CAST(N'2025-05-26T21:00:02.5655162' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (81, 133, 5, N'Defensa', CAST(N'2025-05-26T21:00:12.9044554' AS DateTime2))
GO
INSERT [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES (82, 133, 5, N'Envío finalizado y entregado', CAST(N'2025-05-26T21:00:23.2578901' AS DateTime2))
GO
SET IDENTITY_INSERT [dbo].[EtapasSeguimiento] OFF
GO
SET IDENTITY_INSERT [dbo].[Roles] ON 
GO
INSERT [dbo].[Roles] ([Id], [Tipo]) VALUES (1, N'Administrador')
GO
INSERT [dbo].[Roles] ([Id], [Tipo]) VALUES (2, N'Funcionario')
GO
INSERT [dbo].[Roles] ([Id], [Tipo]) VALUES (3, N'Cliente')
GO
SET IDENTITY_INSERT [dbo].[Roles] OFF
GO
SET IDENTITY_INSERT [dbo].[Usuarios] ON 
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (2, N'Facundo', N'Oficial', N'funcofi@gmail.com', N'string', 1)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (3, N'Andrea', N'Pérez', N'andrea.perez@gmail.com', N'cliente123', 2)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (4, N'Martín', N'Rodríguez', N'martin.rod@gmail.com', N'funcionario456', 1)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (5, N'Camila', N'Fernández', N'camila.fer@gmail.com', N'admin789', 2)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (6, N'Juan', N'Gómez', N'juan.gomez@gmail.com', N'cliente2024', 3)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (7, N'Lucía', N'Silva', N'lucia.silva@gmail.com', N'funcionario852', 1)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (8, N'Diego', N'Méndez', N'diego.mendez@gmail.com', N'admin963', 2)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (9, N'Sofía', N'López', N'sofi', N's', 3)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (10, N'Tomás', N'Varela', N'tomas.varela@gmail.com', N'funcionario357', 1)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (11, N'Valentina', N'Cabrera', N'valentina.cabrera@gmail.com', N'admin159', 2)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (14, N'f', N'f', N'f', N'f', 1)
GO
INSERT [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES (15, N'c', N'c', N'c', N'cc', 3)
GO
SET IDENTITY_INSERT [dbo].[Usuarios] OFF
GO
/****** Object:  Index [UQ_NroTracking]    Script Date: 25/6/2025 10:08:55 ******/
ALTER TABLE [dbo].[Envios] ADD  CONSTRAINT [UQ_NroTracking] UNIQUE NONCLUSTERED 
(
	[NroTracking] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Envios] ADD  DEFAULT ('0001-01-01T00:00:00.0000000') FOR [FechaEnviado]
GO
ALTER TABLE [dbo].[Envios] ADD  DEFAULT ('0001-01-01T00:00:00.0000000') FOR [FechaEntregado]
GO
ALTER TABLE [dbo].[Envios]  WITH CHECK ADD  CONSTRAINT [FK_Envios_Agencias_AgenciaId] FOREIGN KEY([AgenciaId])
REFERENCES [dbo].[Agencias] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Envios] CHECK CONSTRAINT [FK_Envios_Agencias_AgenciaId]
GO
ALTER TABLE [dbo].[Envios]  WITH CHECK ADD  CONSTRAINT [FK_Envios_Usuarios_ClienteId] FOREIGN KEY([ClienteId])
REFERENCES [dbo].[Usuarios] ([Id])
GO
ALTER TABLE [dbo].[Envios] CHECK CONSTRAINT [FK_Envios_Usuarios_ClienteId]
GO
ALTER TABLE [dbo].[Envios]  WITH CHECK ADD  CONSTRAINT [FK_Envios_Usuarios_FuncionarioId] FOREIGN KEY([FuncionarioId])
REFERENCES [dbo].[Usuarios] ([Id])
GO
ALTER TABLE [dbo].[Envios] CHECK CONSTRAINT [FK_Envios_Usuarios_FuncionarioId]
GO
ALTER TABLE [dbo].[EtapasSeguimiento]  WITH CHECK ADD  CONSTRAINT [FK_EtapasSeguimiento_Envios_EnvioId] FOREIGN KEY([EnvioId])
REFERENCES [dbo].[Envios] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EtapasSeguimiento] CHECK CONSTRAINT [FK_EtapasSeguimiento_Envios_EnvioId]
GO
ALTER TABLE [dbo].[EtapasSeguimiento]  WITH CHECK ADD  CONSTRAINT [FK_EtapasSeguimiento_Usuarios_FuncionarioId] FOREIGN KEY([FuncionarioId])
REFERENCES [dbo].[Usuarios] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EtapasSeguimiento] CHECK CONSTRAINT [FK_EtapasSeguimiento_Usuarios_FuncionarioId]
GO
ALTER TABLE [dbo].[Usuarios]  WITH CHECK ADD  CONSTRAINT [FK_Usuarios_Roles_RolId] FOREIGN KEY([RolId])
REFERENCES [dbo].[Roles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Usuarios] CHECK CONSTRAINT [FK_Usuarios_Roles_RolId]
GO

-- INSERTS CHATGPT

-- 🔵 Agencias (IDs 11-25)
SET IDENTITY_INSERT [dbo].[Agencias] ON
INSERT INTO [dbo].[Agencias] ([Id], [Nombre_Valor], [DireccionPostal_Valor], [Latitud], [Longitud]) VALUES
(11, N'Agencia Unión', N'11500', -34.884000, -56.171000),
(12, N'Central Cargo', N'11300', -34.892500, -56.174300),
(13, N'MonteCargo', N'11400', -34.899900, -56.178000),
(14, N'Envíos Express', N'11600', -34.887700, -56.169400),
(15, N'Traslado Sur', N'11200', -34.891700, -56.180100),
(16, N'CityPack', N'11100', -34.895600, -56.186900),
(17, N'Correo Rápido', N'11900', -34.893300, -56.173300),
(18, N'Velocargo', N'11700', -34.888800, -56.166600),
(19, N'MaxiEnvios', N'11050', -34.901200, -56.177800),
(20, N'PuntoPack', N'11350', -34.886600, -56.185500),
(21, N'Agencia Norte', N'11110', -34.903100, -56.191900),
(22, N'Logística Este', N'11010', -34.894800, -56.176000),
(23, N'Expreso Capital', N'11850', -34.885500, -56.182400),
(24, N'Mailgo', N'11990', -34.900800, -56.179900),
(25, N'TraPack', N'11220', -34.898700, -56.175500);
SET IDENTITY_INSERT [dbo].[Agencias] OFF

-- 🟡 Usuarios (IDs 16-30)
SET IDENTITY_INSERT [dbo].[Usuarios] ON
INSERT INTO [dbo].[Usuarios] ([Id], [Nombre_Valor], [Apellido_Valor], [Email_Valor], [Contrasena_Valor], [RolId]) VALUES
(16, N'Ana', N'Ríos', N'ana.rios@gmail.com', N'claveana', 3),
(17, N'Carlos', N'Martínez', N'carlos.martinez@gmail.com', N'func2025', 2),
(18, N'Paula', N'Tejera', N'paula.tejera@gmail.com', N'paulita', 1),
(19, N'Mario', N'Díaz', N'mario.diaz@gmail.com', N'mario2025', 3),
(20, N'Florencia', N'Navarro', N'flor.nav@gmail.com', N'flor2025', 2),
(21, N'Rodrigo', N'Suárez', N'rodrisu@gmail.com', N'rodripass', 1),
(22, N'Elena', N'Cano', N'elena.cano@gmail.com', N'elena99', 3),
(23, N'Joaquín', N'Pérez', N'joa.perez@gmail.com', N'joa123', 2),
(24, N'Agustina', N'Morales', N'agus.morales@gmail.com', N'agus2025', 1),
(25, N'Lucas', N'Costa', N'lucas.costa@gmail.com', N'lucasc', 3),
(26, N'Natalia', N'Ruiz', N'natalia.ruiz@gmail.com', N'natyruiz', 2),
(27, N'Alberto', N'Méndez', N'alberto.m@gmail.com', N'albertpass', 1),
(28, N'Julieta', N'Vela', N'julieta.vela@gmail.com', N'julipass', 3),
(29, N'Santiago', N'Paz', N'santi.paz@gmail.com', N'santipaz', 2),
(30, N'Lorena', N'Sosa', N'lorena.sosa@gmail.com', N'lorenita', 1);
SET IDENTITY_INSERT [dbo].[Usuarios] OFF

-- 🟢 Envios (IDs 134-148)
SET IDENTITY_INSERT [dbo].[Envios] ON
INSERT INTO [dbo].[Envios] ([Id], [NroTracking], [Peso], [Estado], [ClienteId], [FuncionarioId], [TipoEnvio], [AgenciaId], [DireccionPostal], [EntregaEficiente], [FechaEnviado], [FechaEntregado]) VALUES
(134, 1235, 4.50, N'EN_PROCESO', 6, 5, N'Urgente', 11, N'Av. Italia 123', 0, SYSDATETIME(), '0001-01-01'),
(135, 1236, 3.20, N'FINALIZADO', 9, 8, N'Comun', 12, N'Colonia 456', 1, '2025-06-20 08:00', '2025-06-21 10:00'),
(136, 1237, 1.00, N'EN_PROCESO', 25, 5, N'Urgente', 13, N'Maldonado 789', 0, SYSDATETIME(), '0001-01-01'),
(137, 1238, 7.75, N'FINALIZADO', 19, 11, N'Comun', 14, N'Soriano 456', 1, '2025-06-22 09:30', '2025-06-22 15:45'),
(138, 1239, 2.30, N'EN_PROCESO', 16, 17, N'Urgente', 15, N'Jackson 1010', 0, SYSDATETIME(), '0001-01-01'),
(139, 1240, 12.00, N'FINALIZADO', 28, 20, N'Comun', 16, NULL, NULL, '2025-06-15 14:00', '2025-06-16 09:00'),
(140, 1241, 5.60, N'EN_PROCESO', 22, 17, N'Urgente', 17, N'Goes 2333', 1, SYSDATETIME(), '0001-01-01'),
(141, 1242, 0.90, N'FINALIZADO', 19, 29, N'Comun', 18, NULL, NULL, '2025-06-10 11:00', '2025-06-10 17:00'),
(142, 1243, 9.99, N'EN_PROCESO', 6, 26, N'Comun', 19, N'Cerro Largo 543', 1, SYSDATETIME(), '0001-01-01'),
(143, 1244, 3.45, N'FINALIZADO', 25, 20, N'Urgente', 20, NULL, NULL, '2025-06-12 08:30', '2025-06-12 18:00'),
(144, 1245, 8.88, N'FINALIZADO', 28, 5, N'Comun', 21, N'Rambla 132', 1, '2025-06-18 10:00', '2025-06-19 11:00'),
(145, 1246, 2.20, N'EN_PROCESO', 19, 3, N'Urgente', 22, N'Marconi 321', 0, SYSDATETIME(), '0001-01-01'),
(146, 1247, 6.66, N'FINALIZADO', 6, 8, N'Comun', 23, NULL, NULL, '2025-06-21 07:00', '2025-06-21 16:00'),
(147, 1248, 4.00, N'FINALIZADO', 22, 11, N'Urgente', 24, N'Villa Española 666', 1, '2025-06-23 10:00', '2025-06-23 12:00'),
(148, 1249, 10.10, N'EN_PROCESO', 9, 3, N'Comun', 25, NULL, NULL, SYSDATETIME(), '0001-01-01');
SET IDENTITY_INSERT [dbo].[Envios] OFF

-- 🟣 EtapasSeguimiento (IDs 83-97)
SET IDENTITY_INSERT [dbo].[EtapasSeguimiento] ON
INSERT INTO [dbo].[EtapasSeguimiento] ([Id], [EnvioId], [FuncionarioId], [Comentario_Valor], [Fecha]) VALUES
(83, 134, 5, N'Ingreso en agencia', SYSDATETIME()),
(84, 135, 8, N'Salida a reparto', '2025-06-20 09:15'),
(85, 135, 8, N'Entregado en destino', '2025-06-21 10:00'),
(86, 136, 5, N'Esperando despacho', SYSDATETIME()),
(87, 137, 11, N'Clasificado en planta', '2025-06-22 10:00'),
(88, 137, 11, N'Entregado al cliente', '2025-06-22 15:45'),
(89, 138, 17, N'Retirado por cliente', SYSDATETIME()),
(90, 139, 20, N'Recibido en depósito', '2025-06-15 15:00'),
(91, 139, 20, N'Entregado correctamente', '2025-06-16 09:00'),
(92, 140, 17, N'Ruta asignada', SYSDATETIME()),
(93, 141, 29, N'Finalizado', '2025-06-10 17:00'),
(94, 142, 26, N'Reprogramado', SYSDATETIME()),
(95, 143, 20, N'Despachado', '2025-06-12 10:00'),
(96, 144, 5, N'En camino', '2025-06-18 16:30'),
(97, 145, 3, N'Ingreso a centro logístico', SYSDATETIME());
SET IDENTITY_INSERT [dbo].[EtapasSeguimiento] OFF
