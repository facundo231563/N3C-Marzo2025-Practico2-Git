﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcepcionesPropias;
using LogicaAccesoDatos.EF;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.EntityFrameworkCore;

namespace LogicaAccesoDatos.Repositorios
{
    public class RepositorioEnviosBD : IRepositorioEnvio
    {
        public EmpresaContext Contexto { get; set; }

        public RepositorioEnviosBD(EmpresaContext contexto)
        {
            Contexto = contexto;
        }

        public void Add(Envio obj)
        {
            if (obj == null)
                throw new DatosInvalidosException("No se proporcionan datos para el alta del envío");

            Contexto.Envios.Add(obj);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(obj).State = EntityState.Added;
            Contexto.Entry(obj.Cliente).State = EntityState.Unchanged;
            Contexto.Entry(obj.Funcionario).State = EntityState.Unchanged;

            if (obj is Comun comun && comun.Agencia != null)
            {
                Contexto.Entry(comun.Agencia).State = EntityState.Unchanged;
            }

            Contexto.SaveChanges();
        }

        public List<Envio> FindAll()
        {
            var envios = Contexto.Envios
                        .Include(env => env.Cliente)
                            .ThenInclude(cliente => cliente.Nombre)
                        .Include(env => env.Cliente)
                            .ThenInclude(cliente => cliente.Apellido)
                        .Include(env => env.Funcionario)
                            .ThenInclude(funcionario => funcionario.Nombre)
                        .Include(env => env.Funcionario)
                            .ThenInclude(funcionario => funcionario.Apellido)
                        .Include(env => env.EtapasSeguimiento)
                        .ToList();

            var enviosComunes = Contexto.Envios
                .OfType<Comun>()
                .Include(env => env.Agencia)
                .ToList();


            return envios.Union(enviosComunes).ToList();
        }
        public Envio FindById(int id)
        {
            var envio = Contexto.Envios
                    .Include(env => env.EtapasSeguimiento)
                    .Include(env => env.Cliente)
                    .Include(env => env.Funcionario)
                    .Where(env => env.Id == id)
                    .SingleOrDefault();

            var envioComun = Contexto.Envios
                    .OfType<Comun>()
                    .Include(env => env.Cliente)
                    .Include(env => env.Funcionario)
                    .Include(env => env.EtapasSeguimiento)
                    .Include(env => env.Agencia)
                    .Where(env => env.Id == id)
                    .SingleOrDefault();

            if (envio == null)
            {
                throw new DatosInvalidosException("No existe un envío con el número de tracking proporcionado");
            }

            if (envioComun != null)
            {
                // Si es un envío común, lo combinamos con el envío encontrado
                envio = envioComun;
            }

            return envio;
        }

        public void Remove(int id)
        {
            Envio aBorrar = FindById(id);

            if (aBorrar == null) throw new DatosInvalidosException("No existe el envío a borrar");

            Contexto.Envios.Remove(aBorrar);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(aBorrar).State = EntityState.Deleted;
            Contexto.SaveChanges();
        }

        public void Update(Envio obj)
        {
            if (obj == null)
                throw new DatosInvalidosException("No se proporcionan datos para la modificación del envío");

            Envio aModificar = FindById(obj.Id);

            Contexto.Entry(aModificar).State = EntityState.Detached;

            Contexto.Envios.Update(obj);
            //La línea anterior es lo mismo que hacer:
            //Contexto.Entry(obj).State = EntityState.Modified;

            Contexto.SaveChanges();
        }

        public Envio FindByTracking(int nroTracking)
        {
            if (nroTracking == null) throw new DatosInvalidosException("No se proporcionó número de tracking");

            var envio = Contexto.Envios
                .Include(env => env.Cliente)
                .Include(env => env.Funcionario)
                .Include(env => env.EtapasSeguimiento)
                .SingleOrDefault(e => e.NroTracking == nroTracking);

            var envioComun = Contexto.Envios
                .OfType<Comun>()
                .Include(env => env.Cliente)
                .Include(env => env.Funcionario)
                .Include(env => env.EtapasSeguimiento)
                .Include(env => env.Agencia)
                .Where(env => env.NroTracking == nroTracking)
                .SingleOrDefault();

            if (envio == null)
            {
                throw new DatosInvalidosException("No existe un envío con el número de tracking proporcionado");
            }

            if (envioComun != null)
            {
                envio = envioComun;
            }

            return envio;
        }

        public IEnumerable<Envio> ObtenerMisEnvios(int idUsu)
        {
            var envios = Contexto.Envios
                            .Include(e => e.EtapasSeguimiento)
                            .Include(e => e.Cliente)
                                .ThenInclude(c => c.Nombre)
                            .Include(e => e.Cliente)
                                .ThenInclude(c => c.Apellido)
                            .Include(e => e.Funcionario)
                                .ThenInclude(f => f.Nombre)
                            .Include(e => e.Funcionario)
                                .ThenInclude(f => f.Apellido)
                            .Where(e => e.Cliente.Id == idUsu)
                            .OrderBy(e => e.FechaEnviado)
                            .ThenBy(e => e.FechaEntregado)
                            .ToList();

            var enviosComunes = Contexto.Envios
                                .OfType<Comun>()
                                .Include(env => env.Agencia)
                                .Where(e => e.Cliente.Id == idUsu)
                                .OrderBy(e => e.FechaEnviado)
                                .ThenBy(e => e.FechaEntregado)
                                .ToList();


            return envios.Union(enviosComunes).ToList();
        }

        public IEnumerable<Envio> FindByFechas(int id, DateTime fechaDesde, DateTime fechaHasta, string estado)
        {
            if (fechaDesde > fechaHasta) throw new DatosInvalidosException("La fecha de inicio no puede ser posterior a la fecha de fin");

            var envios = Contexto.Envios
                        .Where(e => e.Cliente.Id == id)
                        .Where(e => e.FechaEnviado >= fechaDesde && e.FechaEnviado <= fechaHasta);

            if (estado.ToUpper() != "TODOS") envios = envios.Where(e => e.Estado.ToUpper() == estado.ToUpper());

            var listaEnvios = envios
                            .Include(e => e.EtapasSeguimiento)
                            .Include(e => e.Cliente)
                                .ThenInclude(c => c.Nombre)
                            .Include(e => e.Cliente)
                                .ThenInclude(c => c.Apellido)
                            .Include(e => e.Funcionario)
                                .ThenInclude(f => f.Nombre)
                            .Include(e => e.Funcionario)
                                .ThenInclude(f => f.Apellido)
                            .OrderBy(e => e.NroTracking)
                            .ToList();

            var comunes = Contexto.Envios
                            .OfType<Comun>()
                            .Where(e => e.Cliente.Id == id)
                            .Where(e => e.FechaEnviado >= fechaDesde && e.FechaEnviado <= fechaHasta);

            if (estado.ToUpper() != "TODOS") comunes = comunes.Where(e => e.Estado.ToUpper() == estado.ToUpper());

            var listaComunes = comunes
                            .Include(e => e.Agencia)
                            .OrderBy(e => e.NroTracking)
                            .ToList();

            return listaEnvios.Union(listaComunes).OrderBy(e => e.NroTracking).ToList();
        }

            public IEnumerable<Envio> FindByComentario(int id, string comentario)
            {
                var envios = Contexto.Envios
                                .Include(e => e.Cliente)
                                    .ThenInclude(c => c.Nombre)
                                .Include(e => e.Cliente)
                                    .ThenInclude(c => c.Apellido)
                                .Include(e => e.Funcionario)
                                    .ThenInclude(f => f.Nombre)
                                .Include(e => e.Funcionario)
                                    .ThenInclude(f => f.Apellido)
                                .Include(e => e.EtapasSeguimiento)
                                .Where(e => e.Cliente.Id == id &&
                                            e.EtapasSeguimiento.Any(et => et.Comentario.Valor.Contains(comentario)))
                                .OrderBy(e => e.FechaEnviado)
                                .ToList();

                var enviosComunes = Contexto.Envios
                                   .OfType<Comun>()
                                   .Include(e => e.Cliente)
                                        .ThenInclude(c => c.Nombre)
                                    .Include(e => e.Cliente)
                                        .ThenInclude(c => c.Apellido)
                                    .Include(e => e.Funcionario)
                                        .ThenInclude(f => f.Nombre)
                                    .Include(e => e.Funcionario)
                                        .ThenInclude(f => f.Apellido)
                                    .Include(e => e.EtapasSeguimiento)
                                   .Include(env => env.Agencia)
                                   .Where(e => e.Cliente.Id == id &&
                                               e.EtapasSeguimiento.Any(et => et.Comentario.Valor.Contains(comentario)))
                                    .OrderBy(e => e.FechaEnviado)
                                   .ToList();


                return envios.Union(enviosComunes).ToList();
            }
    }
}

