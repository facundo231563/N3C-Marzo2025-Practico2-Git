﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaNegocio.EntidadesDominio;

namespace LogicaNegocio.InterfacesRepositorios
{
    public interface IRepositorioEnvio:IRepositorio<Envio>
    {
        Envio FindByTracking(int nroTracking);
        IEnumerable<Envio> ObtenerMisEnvios(int idUsu);
        IEnumerable<Envio> FindByFechas(int id, DateTime fechaDesde, DateTime fechaHasta, string estado);
        IEnumerable<Envio> FindByComentario(int id, string comentario);
    }
}
