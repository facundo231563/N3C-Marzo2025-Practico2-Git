﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaNegocio.ValueObjects;

namespace LogicaNegocio.EntidadesDominio
{
  
    public class Rol
    {
        public int Id { get; set; }
        public string Tipo { get; set; } //"Administrador", "Funcionario", "Cliente"

    }

}
