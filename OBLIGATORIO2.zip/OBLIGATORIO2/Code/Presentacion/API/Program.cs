using System.Reflection;
using System.Security.Claims;
using System.Text;
using CasosUso.InterfacesCasosUso;
using LogicaAccesoDatos.EF;
using LogicaAccesoDatos.Repositorios;
using LogicaAplicacion.CasosUsoConcreto;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddScoped<IAltaEnvio, AltaEnvio>();
builder.Services.AddScoped<IListadoEnvios, ListadoEnvios>();
builder.Services.AddScoped<IBuscarEnvioPorId, BuscarEnvioPorId>();
builder.Services.AddScoped<IBajaEnvio, BajaEnvio>();
builder.Services.AddScoped<IModificarEnvio, ModificarEnvio>();
builder.Services.AddScoped<ITrackingEnvio, TrackingEnvio>();
builder.Services.AddScoped<IMisEnvios, MisEnvios>();
builder.Services.AddScoped<IBuscarPorFechas, BuscarPorFechas>();
builder.Services.AddScoped<IBuscarPorComentario, BuscarPorComentario>();


builder.Services.AddScoped<IAltaUsuario, AltaUsuario>();
builder.Services.AddScoped<IListadoUsuarios, ListadoUsuarios>();
builder.Services.AddScoped<IBuscarUsuarioPorId, BuscarUsuarioPorId>();
builder.Services.AddScoped<IBajaUsuario, BajaUsuario>();
builder.Services.AddScoped<IModificarUsuario, ModificarUsuario>();
builder.Services.AddScoped<ILoginUsuario, LoginUsuario>();
builder.Services.AddScoped<IModificarContrasena, ModificarContrasena>();


builder.Services.AddScoped<IRepositorioEnvio, RepositorioEnviosBD>();
builder.Services.AddScoped<IRepositorioUsuario, RepositorioUsuariosBD>();

//PARA EL LOGIN 
builder.Services.AddSession();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddHttpContextAccessor();

//CONFIGURACI�N DE D.I. DEL CONTEXTO DE EF  
string strCon = builder.Configuration.GetConnectionString("MiConexion");
builder.Services.AddDbContext<EmpresaContext>(options => options.UseSqlServer(strCon));

builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

//CAMBIAMOS LO ANTERIOR POR ESTO PARA PODER AUTENTICAR CON JWT EN SWAGGER:

builder.Services.AddSwaggerGen(options =>
{
    var archivo = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var ruta = Path.Combine(AppContext.BaseDirectory, archivo);

    options.IncludeXmlComments(ruta);

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

//////// FIN C�DIGO PARA JWT EN SWAGGER

//////////////// INICIO C�DIGO PARA CONFIGURAR USO DE JWT

var claveSecreta = "ZWRpw6fDo28gZW0gY29tcHV0YWRvcmE=";

builder.Services.AddAuthentication(aut =>
{
    aut.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    aut.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(aut =>
{
    aut.RequireHttpsMetadata = false;
    aut.SaveToken = true;
    aut.TokenValidationParameters = new TokenValidationParameters
    {
        RoleClaimType = ClaimTypes.Role,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(claveSecreta)),
        ValidateIssuer = false,
        ValidateAudience = false
    };
});

//////////////// FIN C�DIGO PARA CONFIGURAR USO DE JWT

var app = builder.Build();

// Configure the HTTP request pipeline.
if (true)//(app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
