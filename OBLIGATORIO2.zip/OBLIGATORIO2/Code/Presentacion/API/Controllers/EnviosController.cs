﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using ExcepcionesPropias;
using LogicaAccesoDatos.EF;
using LogicaNegocio.InterfacesRepositorios;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnviosController : Controller
    {
        public IAltaEnvio CUAltaEnvio { get; set; }
        public IBajaEnvio CUBajaEnvio { get; set; }
        public IBuscarEnvioPorId CUBuscarEnvioPorId { get; set; }
        public IListadoEnvios CUListadoEnvios { get; set; }
        public IModificarEnvio CUModificarEnvio { get; set; }
        public IBuscarUsuarioPorId CUBuscarUsuarioPorId { get; set; }
        public ITrackingEnvio CUTrackingEnvio { get; set; }
        public IMisEnvios CUMisEnvios { get; set; }
        public IBuscarPorFechas CUPorFechas { get; set; }
        public IBuscarPorComentario CUBuscarPorComentario { get; set; }

        public EnviosController(IAltaEnvio cuAltaEnvio, IBajaEnvio cuBajaEnvio, IBuscarEnvioPorId cuBuscarEnvioPorId, IListadoEnvios cuListadoEnvios, IModificarEnvio cuModificarEnvio, IBuscarUsuarioPorId cuBuscarUsuarioPorId, ITrackingEnvio cuTrackingEnvio, IMisEnvios cuMisEnvios, IBuscarPorFechas cuPorFechas, IBuscarPorComentario cuBuscarComentario)
        {
            CUAltaEnvio = cuAltaEnvio;
            CUBajaEnvio = cuBajaEnvio;
            CUBuscarEnvioPorId = cuBuscarEnvioPorId;
            CUListadoEnvios = cuListadoEnvios;
            CUModificarEnvio = cuModificarEnvio;
            CUBuscarUsuarioPorId = cuBuscarUsuarioPorId;
            CUTrackingEnvio = cuTrackingEnvio;
            CUMisEnvios = cuMisEnvios;
            CUPorFechas = cuPorFechas;
            CUBuscarPorComentario = cuBuscarComentario;
        }

        /// <summary>
        /// Devuelve un envío por número de tracking
        /// </summary>
        /// <param name="nroTracking">El número de tracking del envío</param>
        /// <returns>200 si todo sale bien,  400 si se ingresa un número de tracking menor o igual a cero, 
        ///          404 si el número de tracking no existe</returns>
        /// <remarks>No requiere autenticación</remarks>
        [ProducesResponseType(typeof(EnvioDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        [HttpGet("tracking/{nroTracking}")]
        public IActionResult ObtenerEnvioPorTracking(int nroTracking)
        {
            if (nroTracking <= 0) return BadRequest("El número de tracking debe ser un número positivo mayor que cero");

            try
            {
                var envio = CUTrackingEnvio.EjecutarTracking(nroTracking);

                if (envio == null)
                {
                    return NotFound("El envio con número de tracking =" + nroTracking + " no existe");
                }
                return Ok(envio);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocurrió un error, intente nuevamente más tarde");
            }
        }

        /// <summary>
        /// Permite obtener los envíos del usuario en sesión
        /// </summary>
        /// <param name="id">El id del usuario</param>
        /// <returns>200 si todo sale bien,401 si no estás logeado, 403 si no sos cliente, 
        ///          404 si no se encontró el usuario</returns>
        /// <remarks>Requiere autenticación</remarks>
        [ProducesResponseType(typeof(IEnumerable<EnvioDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(string), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        [HttpGet("mis-envios/{id}")]
        [Authorize(Roles = "Cliente")]
        public IActionResult ObtenerMisEnvios(int id)
        {
            try
            {
                var lista = CUMisEnvios.ObtenerMisEnvios(id);

                if (lista == null)
                    return NotFound("No se encontraron envíos para este cliente.");

                return Ok(lista);
            }
            catch (Exception)
            {
                return StatusCode(500, "Error al recuperar los envíos.");
            }
        }

        /// <summary>
        /// Devuelve envíos según filtro de fechas y estado del usuario en sesión
        /// </summary>
        /// <param name="id">El id del usuario</param>
        /// <param name="fechaDesde">La fecha desde que se busca el envío</param>
        /// <param name="fechaHasta">La fecha hasta que se busca el envío</param>
        /// <param name="estado">El estado que tiene el envío</param>
        /// <returns>200 si todo sale bien, 401 si no estás logeado, 403 si no sos cliente, 400 si los datos son inválidos, 
        ///          404 si no se encuentra el envío</returns>
        /// <remarks>Requiere autenticación</remarks>
        [ProducesResponseType(typeof(IEnumerable<EnvioDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(string), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        [HttpGet("envios-fechayestado/{id}")]
        [Authorize(Roles = "Cliente")]
        public IActionResult FindByFechas(int id, DateTime fechaDesde, DateTime fechaHasta, string estado)
        {
            try
            {
                if (fechaDesde > fechaHasta) return BadRequest("La fecha de inicio no puede ser posterior a la fecha fin.");

                if (string.IsNullOrWhiteSpace(estado)) return BadRequest("Debe especificar un estado válido o 'Todos'.");

                var lista = CUPorFechas.EnviosPorFecha(id, fechaDesde, fechaHasta, estado);

                if (lista == null || !lista.Any()) return NotFound("No se encontraron envíos para este cliente.");

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error al recuperar los envíos.");
            }
        }

        /// <summary>
        /// Devuelve envíos si el comentario en alguna de sus etapas contiene el texto ingresado
        /// </summary>
        /// <param name="id">El id del usuario</param>
        /// <param name="comentario">El texto que se busca en los comentarios de las etapas del envío</param>
        /// <returns>200 si todo sale bien, 400 si los datos son inválidos, 401 si no estás logeado, 403 si no sos cliente,  
        ///          404 si no se encuentra el envío</returns>
        /// <remarks>Requiere autenticación</remarks>
        [ProducesResponseType(typeof(IEnumerable<EnvioDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(string), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        [HttpGet("buscar-por-comentario/{id}")]
        [Authorize(Roles = "Cliente")]
        public IActionResult FindByComentario(int id, string comentario)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(comentario)) return BadRequest("No se encontró el texto");
                var lista = CUBuscarPorComentario.EnviosPorComentario(id, comentario);
                if (lista == null || !lista.Any()) return NotFound("No se encontraron envíos con ese comentario.");
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error al recuperar los envíos.");
            }
        }

        //// GET: api/Envios
        [HttpGet]
        //[Authorize]
        public IActionResult Get()
        {
            try
            {
                var envios = CUListadoEnvios.ObtenerListado();
                return Ok(envios);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocurrió un error, intente nuevamente más tarde");
            }
        }

        // GET api/Envios/5
        [HttpGet("{id}", Name = "RutaBuscarPorId")]
        public IActionResult Get(int id)
        {
            if (id <= 0) return BadRequest("El id debe ser un número positivo mayor que cero");

            try
            {
                var envio = CUBuscarEnvioPorId.EjecutarBusqueda(id);
                if (envio == null)
                {
                    return NotFound("El envio con id=" + id + " no existe");
                }
                return Ok(envio);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocurrió un error, intente nuevamente más tarde");
            }
        }

        // POST api/Envios
        [HttpPost]
        public IActionResult Post([FromBody] EnvioDTO? nuevo)
        {
            if (nuevo == null) return BadRequest("No se proporcionaron datos par el alta");

            try
            {
                CUAltaEnvio.EjecutarAlta(nuevo);
                return CreatedAtRoute("RutaBuscarPorId", new { id = nuevo.Id }, nuevo);
            }
            catch (DatosInvalidosException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocurrió un error inesperado. Intente de nuevo más tarde");
            }

        }

        // PUT api/Envios/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] EnvioDTO? aModificar)
        {
            if (aModificar == null) return BadRequest("No se proporcionaron datos par la modificación");

            if (aModificar.Id != id) return BadRequest("No coincide el id a modificar");

            try
            {
                CUModificarEnvio.EjecutarModificacion(aModificar);
                return Ok(aModificar);
            }
            catch (DatosInvalidosException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocurrió un error inesperado. Intente de nuevo más tarde");
            }
        }

        // DELETE api/Envios/8
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            if (id <= 0) return BadRequest("El id debe ser un número positivo mayor que cero");

            try
            {
                var envio = CUBuscarEnvioPorId.EjecutarBusqueda(id);
                if (envio == null)
                {
                    return NotFound("El envío con id=" + id + " no existe");
                }

                CUBajaEnvio.EjecutarBaja(id);
                return NoContent();
            }
            catch (DatosInvalidosException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (OperacionConflictivaException ex)
            {
                return Conflict(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocurrió un error, intente nuevamente más tarde");
            }
        }
    }
}
