﻿using API.JWT;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using ExcepcionesPropias;
using LogicaAplicacion.CasosUsoConcreto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        public  ILoginUsuario CULogin{ get; set; }
        public IModificarContrasena CUModifPW { get; set; }

        public UsuarioController(ILoginUsuario cuLogin, IModificarContrasena cuContrasena)
        {
            CULogin = cuLogin;
            CUModifPW = cuContrasena;
        }

        /// <summary>
        /// Permite logearse a la web
        /// </summary>
        /// <param name="dto">El usuario a logearse</param>
        /// <returns>200 o 401 si no lo encuentra o los datos no coinciden</returns>
        /// <remarks>No requiere autenticación</remarks>
        [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string),StatusCodes.Status401Unauthorized)]
        [AllowAnonymous] //Habilita acceso a endpoint sin autenticación
        [HttpPost]
        public IActionResult Login([FromBody] UsuarioDTO dto)
        {
            UsuarioDTO usuario = CULogin.EjecutarLogin(dto.Email,dto.Contrasena);

            if(usuario == null) return Unauthorized("Credenciales inválidas"); //401

            string token = ManejadorJWT.GenerarToken(usuario);

            var contenido = new {usuario.Email, Rol=usuario.TipoRol, Token = token, usuario.Id};

            return Ok(contenido); //200
        }

        /// <summary>
        /// Permite modificar contraseña del usuario en sesión
        /// </summary>
        /// <param name="dto">El usuario a modificar</param>
        /// <returns>200 si todo sale bien, 401 si no estás logeado ,403 si no sos cliente, 400 si los datos son inválidos</returns>
        /// <remarks>Requiere autenticación</remarks>
        [ProducesResponseType(typeof(CambioContrasenaDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(string), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        [HttpPut("cambiar-contrasena")]
        [Authorize(Roles = "Cliente")]
        public IActionResult ModificarContrasena([FromBody] CambioContrasenaDTO dto)
        {
            if (dto == null)
                return BadRequest("Datos de entrada inválidos");

            try
            {
                CUModifPW.EjecutarNuevaContrasena(dto);
                return Ok("Contraseña actualizada correctamente");
            }
            catch (DatosInvalidosException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return StatusCode(500, "Error inesperado al cambiar la contraseña");
            }
        }

    }
}
