﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasosUso.DTOs
{
    public class CambioContrasenaDTO
    {
        public string Email { get; set; }
        public string ContrasenaActual { get; set; }
        public string ContrasenaNueva { get; set; }

    }
}
