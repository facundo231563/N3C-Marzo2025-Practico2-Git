﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.InterfacesRepositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static LogicaAplicacion.CasosUsoConcreto.ModificarContrasena;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class ModificarContrasena : IModificarContrasena
    {
        public IRepositorioUsuario RepoUsu { get; set; }

        public ModificarContrasena(IRepositorioUsuario repo)
        {
            RepoUsu = repo;
        }

        public void EjecutarNuevaContrasena(CambioContrasenaDTO dto)
        {
            RepoUsu.ModificarContrasena(dto.Email, dto.ContrasenaActual, dto.ContrasenaNueva);
        }
    }
}
