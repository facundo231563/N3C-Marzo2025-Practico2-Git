﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaNegocio.InterfacesRepositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class MisEnvios : IMisEnvios
    {
        public IRepositorioEnvio RepoEnvios { get; set; }

        public MisEnvios(IRepositorioEnvio repoEnvios)
        {
            RepoEnvios = repoEnvios;
        }
        public IEnumerable<EnvioDTO> ObtenerMisEnvios(int idUsu)
        {
            return MappersEnvio.ToListaEnviosDTO(RepoEnvios.ObtenerMisEnvios(idUsu));
        }
    }
}
