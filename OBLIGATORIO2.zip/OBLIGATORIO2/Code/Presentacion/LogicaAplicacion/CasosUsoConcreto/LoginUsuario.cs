﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{

    public class LoginUsuario : ILoginUsuario
    {
        public IRepositorioUsuario RepoUsuarios { get; set; }

        public LoginUsuario(IRepositorioUsuario repoUsuarios)
        {
            RepoUsuarios = repoUsuarios;
        }
        public UsuarioDTO EjecutarLogin(string email, string contrasena)
        {
            Usuario buscado = RepoUsuarios.Login(email, contrasena);
            return MappersUsuario.ToUsuarioDTO(buscado);
        }
    }
}
