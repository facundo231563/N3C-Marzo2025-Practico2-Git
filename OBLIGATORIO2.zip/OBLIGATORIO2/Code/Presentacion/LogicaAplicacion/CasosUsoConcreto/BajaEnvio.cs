﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.InterfacesCasosUso;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class BajaEnvio : IBajaEnvio
    {
        public IRepositorioEnvio RepoEnvios { get; set; }

        public BajaEnvio(IRepositorioEnvio repo)
        {
            RepoEnvios = repo;
        }

        public void EjecutarBaja(int id)
        {
            RepoEnvios.Remove(id);
        }
    }
}
