﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaNegocio.InterfacesRepositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class BuscarPorFechas : IBuscarPorFechas
    {
        public IRepositorioEnvio RepoEnvios{ get; set; }

        public BuscarPorFechas(IRepositorioEnvio repo)
        {
            RepoEnvios = repo;
        }
      
        public IEnumerable<EnvioDTO> EnviosPorFecha(int id, DateTime fechaDesde, DateTime fechaHasta, string estado)
        {
            return MappersEnvio.ToListaEnviosDTO(RepoEnvios.FindByFechas(id, fechaDesde, fechaHasta, estado));
        }
    }
}
