﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaAplicacion.Mapeadores;
using LogicaNegocio.EntidadesDominio;
using LogicaNegocio.InterfacesRepositorios;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class TrackingEnvio : ITrackingEnvio
    {
        public IRepositorioEnvio RepoEnvios { get; set; }
        public TrackingEnvio(IRepositorioEnvio repoEnvios)
        {
            RepoEnvios = repoEnvios;
        }
        public EnvioDTO EjecutarTracking(int nroTracking)
        {
            Envio e = RepoEnvios.FindByTracking(nroTracking);
            return MappersEnvio.ToEnvioDTO(e);
        }

    }
}
