﻿using CasosUso.DTOs;
using CasosUso.InterfacesCasosUso;
using LogicaNegocio.InterfacesRepositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUsoConcreto
{
    public class BuscarPorComentario : IBuscarPorComentario
    {
        public IRepositorioEnvio RepoEnvios { get; set; }
        public BuscarPorComentario(IRepositorioEnvio repo)
        {
            RepoEnvios = repo;
        }
        public IEnumerable<EnvioDTO> EnviosPorComentario(int id, string comentario)
        {

            return MappersEnvio.ToListaEnviosDTO(RepoEnvios.FindByComentario(id, comentario));
        }
    }
}
