﻿using WebMVC.DTOs;

namespace WebMVC.Models
{
    public class BuscarEnviosViewModel
    {
        public FiltroFechasDTO Filtros { get; set; }
        public List<EnvioDTO> Resultados { get; set; } = new List<EnvioDTO>();
    }
}
