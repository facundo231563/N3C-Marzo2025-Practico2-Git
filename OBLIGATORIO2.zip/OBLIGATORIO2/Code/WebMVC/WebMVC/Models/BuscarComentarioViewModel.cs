﻿using WebMVC.DTOs;

namespace WebMVC.Models
{
    public class BuscarComentarioViewModel
    {
        public string FraseClave { get; set; }
        public List<EnvioDTO> Resultados { get; set; } = new List<EnvioDTO>();
    }
}
