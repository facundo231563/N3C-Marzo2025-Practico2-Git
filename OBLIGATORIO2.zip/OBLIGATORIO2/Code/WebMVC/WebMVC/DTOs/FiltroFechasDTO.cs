﻿namespace WebMVC.DTOs
{
    public class FiltroFechasDTO
    {
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Estado { get; set; } = "Todos";

    }
}
