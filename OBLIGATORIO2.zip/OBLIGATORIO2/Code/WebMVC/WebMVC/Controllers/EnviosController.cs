﻿using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Linq.Expressions;
using WebMVC.DTOs;
using WebMVC.Models;
//using Presentacion.Models;

namespace WebMVC.Controllers
{
    public class EnviosController : Controller
    {
        public string URLApi { get; set; }

        public EnviosController(IConfiguration config)
        {
            URLApi = config.GetValue<string>("UrlApiEnvios");
        }

        //Get BuscarPorTracking
        [HttpGet]
        public IActionResult BuscarPorTracking(int? nroTracking)
        {
            if (nroTracking == null)
                return View();

            try
            {
                string urlConTracking = $"{URLApi}tracking/{nroTracking}";

                HttpResponseMessage resultado = AuxiliarClienteHttp.EnviarSolicitud(urlConTracking, "get", null, null);
                string body = AuxiliarClienteHttp.ObtenerBody(resultado);

                if (resultado.IsSuccessStatusCode)
                {
                    var envio = JsonConvert.DeserializeObject<EnvioDTO>(body);
                    return View(envio);
                }
                else
                {
                    ViewBag.Error = $"No se encontró el envío con tracking {nroTracking}";
                    return View();
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado al consultar el envío";
                return View();
            }
        }

        [HttpGet]
        public IActionResult VerEtapas(int nroTracking)
        {
            try
            {
                string urlConTracking = $"{URLApi}tracking/{nroTracking}";
                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(urlConTracking, "get", null, null);
                string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                if (respuesta.IsSuccessStatusCode)
                {
                    var envio = JsonConvert.DeserializeObject<EnvioDTO>(body);
                    return View(envio.EtapasSeguimiento);
                }
                else
                {
                    ViewBag.Error = $"No se encontraron etapas para el envío {nroTracking}";
                    return View(new List<EtapaSeguimientoDTO>());
                }
            }
            catch
            {
                ViewBag.Error = "Ocurrió un error al cargar las etapas";
                return View(new List<EtapaSeguimientoDTO>());
            }
        }

        [HttpGet]
        public IActionResult MisEnvios()
        {
            string rol = HttpContext.Session.GetString("rol");

            if (string.IsNullOrEmpty(rol) || rol != "Cliente")
            {
                HttpContext.Session.Clear();
                TempData["Error"] = "Debe logearse como cliente para acceder a la funcionalidad";
                return RedirectToAction("Login", "Usuarios");
            }

            try
            {
                int idCliente = (int)HttpContext.Session.GetInt32("id");
                string url = $"{URLApi}mis-envios/{idCliente}";

                string token = HttpContext.Session.GetString("token");

                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(url, "get", null, token);
                string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                if (respuesta.IsSuccessStatusCode)
                {
                    var lista = JsonConvert.DeserializeObject<List<EnvioDTO>>(body);
                    return View(lista);
                }
                else
                {
                    ViewBag.Error = body;
                    return View(new List<EnvioDTO>());
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error al obtener los envíos";
                return View(new List<EnvioDTO>());
            }
        }

        [HttpGet]
        public IActionResult VerEtapasMisEnvios(int idEnvio)
        {
            string rol = HttpContext.Session.GetString("rol");

            if (string.IsNullOrEmpty(rol) || rol != "Cliente")
            {
                HttpContext.Session.Clear();
                TempData["Error"] = "Debe logearse como cliente para acceder a la funcionalidad";
                return RedirectToAction("Login", "Usuarios");
            }

            try
            {
                string url = $"{URLApi}{idEnvio}";
                string token = HttpContext.Session.GetString("token");
                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(url, "get", null, token);
                string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                if (respuesta.IsSuccessStatusCode)
                {
                    var envio = JsonConvert.DeserializeObject<EnvioDTO>(body);
                    return View("VerEtapasMisEnvios", envio.EtapasSeguimiento);
                }
                else
                {
                    ViewBag.Error = $"No se encontraron etapas para el envío {idEnvio}";
                    return View("VerEtapasMisEnvios", new List<EtapaSeguimientoDTO>());
                }
            }
            catch
            {
                ViewBag.Error = "Ocurrió un error al cargar las etapas";
                return View("VerEtapasMisEnvios", new List<EtapaSeguimientoDTO>());
            }
        }

        [HttpGet]
        public IActionResult BuscarEnvios(DateTime? fechaDesde, DateTime? fechaHasta, string estado = "TODOS")
        {
            string rol = HttpContext.Session.GetString("rol");

            if (string.IsNullOrEmpty(rol) || rol != "Cliente")
            {
                HttpContext.Session.Clear();
                TempData["Error"] = "Debe logearse como cliente para acceder a la funcionalidad";
                return RedirectToAction("Login", "Usuarios");
            }

            var viewModel = new BuscarEnviosViewModel
            {
                Filtros = new FiltroFechasDTO
                {
                    FechaInicio = fechaDesde ?? DateTime.Today.AddDays(-30),
                    FechaFin = fechaHasta ?? DateTime.Today,
                    Estado = estado
                },
                Resultados = new List<EnvioDTO>()
            };

            // Si el usuario aún no usó el botón "Buscar", no hacemos el llamado a la API
            if (!fechaDesde.HasValue || !fechaHasta.HasValue)
                return View("BuscarEnviosPorFechas", viewModel);

            if (fechaDesde > fechaHasta)
            {
                ViewBag.Error = "La fecha de inicio debe ser anterior o igual a la fecha de fin.";
            }
            else
            {
                try
                {
                    int idUsu = (int)HttpContext.Session.GetInt32("id");
                    string token = HttpContext.Session.GetString("token");

                    string url = $"{URLApi}envios-fechayestado/{idUsu}" +
                                 $"?fechaDesde={fechaDesde:yyyy-MM-dd}" +
                                 $"&fechaHasta={fechaHasta:yyyy-MM-dd}" +
                                 $"&estado={estado}";

                    HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(url, "get", null, token);
                    string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                    if (respuesta.IsSuccessStatusCode)
                    {
                        viewModel.Resultados = JsonConvert.DeserializeObject<List<EnvioDTO>>(body);
                    }
                    else
                    {
                        ViewBag.Error = "No se encontraron envíos con los filtros seleccionados.";
                    }
                }
                catch
                {
                    ViewBag.Error = "Ocurrió un error durante la búsqueda.";
                }
            }

            return View("BuscarEnviosPorFechas", viewModel);
        }

        [HttpGet]
        public IActionResult BuscarPorComentario(string frase)
        {
            string rol = HttpContext.Session.GetString("rol");

            if (string.IsNullOrEmpty(rol) || rol != "Cliente")
            {
                HttpContext.Session.Clear();
                TempData["Error"] = "Debe logearse como cliente para acceder a la funcionalidad";
                return RedirectToAction("Login", "Usuarios");
            }

            var viewModel = new BuscarComentarioViewModel { FraseClave = frase };

            if (string.IsNullOrWhiteSpace(frase))
                return View("BuscarPorComentario", viewModel);

            try
            {
                int idUsu = (int)HttpContext.Session.GetInt32("id");
                string token = HttpContext.Session.GetString("token");

                string url = $"{URLApi}buscar-por-comentario/{idUsu}?comentario={frase}";

                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(url, "get", null, token);
                string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                if (respuesta.IsSuccessStatusCode)
                {
                    viewModel.Resultados = JsonConvert.DeserializeObject<List<EnvioDTO>>(body);
                }
                else
                {
                    ViewBag.Error = "No se encontraron envíos con esa palabra.";
                }
            }
            catch
            {
                ViewBag.Error = "Ocurrió un error durante la búsqueda.";
            }

            return View("BuscarPorComentario", viewModel);
        }

        // GET: EnviosController
        public IActionResult Index()
        {
            List<EnvioDTO> envios = new List<EnvioDTO>();

            try
            {
                //string rol = HttpContext.Session.GetString("rol");
                //if (string.IsNullOrEmpty(rol))
                //    return RedirectToAction("Login", "Usuarios");

                string token = HttpContext.Session.GetString("token");
                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(URLApi, "get", null, token);

                string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                if (respuesta.IsSuccessStatusCode)
                {
                    envios = JsonConvert.DeserializeObject<List<EnvioDTO>>(body);
                }
                else
                {
                    if ((int)respuesta.StatusCode == 401)
                    {
                        ViewBag.Error = "Credenciales inválidas";
                    }
                    else
                    {
                        ViewBag.Error = body;
                    }
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(envios);
        }

        // GET: EnviosController/Details/5
        public IActionResult Details(int id)
        {
            EnvioDTO envio = null;

            try
            {
                HttpResponseMessage resultado = AuxiliarClienteHttp.EnviarSolicitud(URLApi + id, "get", null, null);
                string body = AuxiliarClienteHttp.ObtenerBody(resultado);

                if (resultado.IsSuccessStatusCode)
                {
                    envio = JsonConvert.DeserializeObject<EnvioDTO>(body);
                }
                else
                {
                    ViewBag.Error = body;
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(envio);
        }

        // GET: EnviosController/Create
        public IActionResult Create()
        {
            string rol = HttpContext.Session.GetString("rol");
            if (string.IsNullOrEmpty(rol) || rol != "Administrador")
                return RedirectToAction("Login", "Usuarios");

            return View();
        }

        // POST: EnviosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(EnvioDTO dto)
        {
            try
            {
                string token = HttpContext.Session.GetString("token");
                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(URLApi, "post", dto, token);

                if (respuesta.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    string error = AuxiliarClienteHttp.ObtenerBody(respuesta);
                    ViewBag.Error = error;
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(dto);
        }

        // GET: EnviosController/Edit/5
        public IActionResult Edit(int id)
        {
            EnvioDTO envio = null;

            try
            {
                HttpResponseMessage resultado = AuxiliarClienteHttp.EnviarSolicitud(URLApi + id, "get", null, null);
                string body = AuxiliarClienteHttp.ObtenerBody(resultado);

                if (resultado.IsSuccessStatusCode)
                {
                    envio = JsonConvert.DeserializeObject<EnvioDTO>(body);
                }
                else
                {
                    ViewBag.Error = body;
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(envio);
        }

        // POST: EnviosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, EnvioDTO dto)
        {
            try
            {
                HttpResponseMessage resultado = AuxiliarClienteHttp.EnviarSolicitud(URLApi + id, "put", dto, null);

                if (resultado.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ViewBag.Error = AuxiliarClienteHttp.ObtenerBody(resultado);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(dto);
        }

        // GET: EnviosController/Delete/5
        public IActionResult Delete(int id)
        {
            EnvioDTO envio = null;

            try
            {
                HttpResponseMessage resultado = AuxiliarClienteHttp.EnviarSolicitud(URLApi + id, "get", null, null);
                string body = AuxiliarClienteHttp.ObtenerBody(resultado);

                if (resultado.IsSuccessStatusCode)
                {
                    envio = JsonConvert.DeserializeObject<EnvioDTO>(body);
                }
                else
                {
                    ViewBag.Error = body;
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(envio);
        }

        // POST: EnviosController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id, EnvioDTO dto)
        {
            try
            {
                HttpResponseMessage resultado = AuxiliarClienteHttp.EnviarSolicitud(URLApi + id, "delete", null, null);

                if (resultado.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ViewBag.Error = AuxiliarClienteHttp.ObtenerBody(resultado);
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
            }

            return View(dto);
        }
    }
}
