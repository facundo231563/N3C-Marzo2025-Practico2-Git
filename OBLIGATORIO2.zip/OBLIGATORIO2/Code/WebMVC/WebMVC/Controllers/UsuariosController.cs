﻿using CasosUso.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebMVC.DTOs;

namespace WebMVC.Controllers
{
    public class UsuariosController : Controller
    {
        public string URLApi { get; set; }
        public UsuariosController(IConfiguration config)
        {
            URLApi = config.GetValue<string>("UrlApiUsuarios");
        }


        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Login(UsuarioDTO dto)
        {
            var respuesta = AuxiliarClienteHttp.EnviarSolicitud(URLApi, "post", dto, null);
            string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

            if (respuesta.IsSuccessStatusCode)
            {

                UsuarioDTO usu = JsonConvert.DeserializeObject<UsuarioDTO>(body);
                HttpContext.Session.SetString("rol", usu.Rol);
                HttpContext.Session.SetString("token", usu.Token);
                HttpContext.Session.SetString("email", usu.Email);
                HttpContext.Session.SetInt32("id", usu.Id);

                return RedirectToAction("Index", "Envios");
            }
            else
            {
                if ((int)respuesta.StatusCode == 401)
                {
                    ViewBag.Error = "Credenciales inválidas";
                }
                else
                {
                    ViewBag.Error = "Hubo un error y no se pudo iniciar sesión";
                }
            }

            return View();
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Envios");
        }

        [HttpGet]
        public IActionResult ModificarContrasena()
        {
            string rol = HttpContext.Session.GetString("rol");

            if (string.IsNullOrEmpty(rol) || rol != "Cliente")
            {
                HttpContext.Session.Clear();
                TempData["Error"] = "Debe logearse como cliente para acceder a la funcionalidad";
                return RedirectToAction("Login", "Usuarios");
            }

            var dto = new CambioContrasenaDTO
            {
                //Precargo email
                Email = HttpContext.Session.GetString("email")
            };

            return View(dto);
        }

        [HttpPost]
        public IActionResult ModificarContrasena(CambioContrasenaDTO dto)
        {
            try
            {
                string url = $"{URLApi}cambiar-contrasena";
                string token = HttpContext.Session.GetString("token");
                HttpResponseMessage respuesta = AuxiliarClienteHttp.EnviarSolicitud(url, "put", dto, token);
                string body = AuxiliarClienteHttp.ObtenerBody(respuesta);

                if (respuesta.IsSuccessStatusCode)
                {
                    ViewBag.Mensaje = "La contraseña fue modificada correctamente";
                    return View(new CambioContrasenaDTO());
                }
                else
                {
                    if ((int)respuesta.StatusCode == 401)
                    {
                        ViewBag.Error = "Usted no es cliente";
                    }
                    else
                    {
                        ViewBag.Error = "No se pudo cambiar la contraseña";
                    }
                }
                return View(dto);
            }
            catch (Exception)
            {
                ViewBag.Error = "Ocurrió un error inesperado";
                return View(dto);
            }
        }

    }
}
